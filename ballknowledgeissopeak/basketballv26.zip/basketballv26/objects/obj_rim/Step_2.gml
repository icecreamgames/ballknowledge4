if (!instance_exists(obj_basketball))
{
	qa = noone
	qb = noone
	exit
}

var cd = instance_find(obj_basketball, 0)
var s3 = bbox_left + s2
var s5 = bbox_right - s2
var s6 = bbox_top + s7
var s1 = (s3 + s5) / 2
var bx = (cd.bbox_left + cd.bbox_right) / 2
var by = (cd.bbox_top + cd.bbox_bottom) / 2
var ce = max(cd.bbox_right - cd.bbox_left, cd.bbox_bottom - cd.bbox_top) / 2

if qa == noone
{
	qa = bx
	qb = by
}

var dx = bx - qa
var dy = by - qb

if (point_distance(qa, qb, bx, by) > 200)
{
	qa = bx
	qb = by

	dx = 0
	dy = 0
}

var jr = false
var ct = 2
var cr = 0
var cs = 0
var cp = 0
var cq = 0

for (var i = 0; i < 2; i++)
{
	var rx = s3

	if i == 1
	rx = s5

	var ry = s6
	var q9 = ce + s4
	var fx = qa - rx
	var fy = qb - ry
	var a = dx * dx + dy * dy
	var b = 2 * (fx * dx + fy * dy)
	var c = fx * fx + fy * fy - q9 * q9
	var t = 2

	if c <= 0
	{
		t = 0
	}
	else if a > 0.0001
	{
		var gm = b * b - 4 * a * c

		if gm >= 0
		{
			t = (-b - sqrt(gm)) / (2 * a)
		}
	}

	if t >= 0 and t <= 1 and t < ct
	{
		var cx = qa + dx * t
		var cy = qb + dy * t
		var nx = cx - rx
		var ny = cy - ry
		var lk = point_distance(0, 0, nx, ny)

		if lk > 0.001
		{
			nx /= lk
			ny /= lk

			var b3 = cd.j1 * nx + cd.yp * ny

			if b3 < -0.1
			{
				ct = t

				cr = rx
				cs = ry

				cp = nx
				cq = ny
			}
		}
	}
}

if ct <= 1
{
	var wk = cr
	+ cp * (ce + s4 + 0.5)

	var wl = cs
	+ cq * (ce + s4 + 0.5)

	cd.x += wk - bx
	cd.y += wl - by

	var gn = cd.j1 * cp
	+ cd.yp * cq

	cd.j1 -= (1 + s0) * gn * cp
	cd.yp -= (1 + s0) * gn * cq

	jr = true
}

if (!jr and cd.yp > 0 and by < s6 and by > s6 - b5 and abs(bx - s1) < b6)
{
	var wj = clamp((s1 - bx) * 0.06, -4, 4)

	cd.j1 = lerp(cd.j1, wj, b7)
}

if !jr and !tx and qb < s6 and by >= s6 and cd.yp > 0
{
	var fp = (s6 - qb)
	/ max(0.001, by - qb)

	var fq = lerp(qa, bx, fp)

	if fq > s3 + s4 and fq < s5 - s4
	{
		global.ty += 1
		tx = true
		effect_create_above(ef_firework,x,y,2,c_red)

		var hs = variable_global_exists("ls")
		and global.ls
		var fv = variable_global_exists("f1")
		and global.f1

		if fv
		{
			global.fw = true
		}

		if hs
		{
			global.lr = true
		}

		if !hs and !fv
		{
			room_goto(rm_scoreboard)
		}

		audio_play_sound(snd_win,1,0)
	}
}

if by < s6 - 40 or by > s6 + 90
{
	tx = false
}

qa = (cd.bbox_left + cd.bbox_right) / 2
qb = (cd.bbox_top + cd.bbox_bottom) / 2

var x0 = s6 + s4
var cf =
(cd.bbox_bottom - cd.bbox_top) / 2

var qd = qb - cf
var fu = cd.bbox_top

if cd.yp < 0
{
	if qd >= x0 and fu <= x0
	{
		var fp = clamp((qd - x0) / max(0.001, qd - fu), 0, 1)

		var fq = lerp(qa, bx, fp)

		if fq + ce > s3 and fq - ce < s5
		{
			cd.y += x0 - cd.bbox_top + 0.5

			cd.yp = max(3, abs(cd.yp) * xz)

			cd.j1 *= 0.95

			qa =
			(cd.bbox_left + cd.bbox_right) / 2

			qb =
			(cd.bbox_top + cd.bbox_bottom) / 2

			exit
		}
	}
}
