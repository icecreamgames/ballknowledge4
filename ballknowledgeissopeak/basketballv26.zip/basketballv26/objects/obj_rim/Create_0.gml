s2 = 4
s7 = 6
xz = 0.85
s4 = 7

s0 = 0.85

b7 = 0.06
b6 = 70
b5 = 90

tx = false

qa = noone
qb = noone

if (!variable_global_exists("ty"))
{
	global.ty = 0
}
