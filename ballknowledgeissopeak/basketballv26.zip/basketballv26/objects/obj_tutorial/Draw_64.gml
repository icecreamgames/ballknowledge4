var cx = display_get_gui_width() / 2
var gh = display_get_gui_height()
var b4 = gh - 115
var kv = gh - 55
var lj = cx - 65
var sz = cx + 65
var tw = 2
var iu = floor(current_time / 500)
var lh = keyboard_check(vk_left)
var su = keyboard_check(vk_right)
var bc = keyboard_check(ord("A"))
var f4 = keyboard_check(ord("D"))
var v4 = sprite_left
var v5 = sprite_right
var v1 = sprite_a
var v2 = sprite_d

if lh
{
	v4 = sprite_left_pressed
}

if su
{
	v5 = sprite_right_pressed
}

if bc
{
	v1 = sprite_a_pressed
}

if f4
{
	v2 = sprite_d_pressed
}

var s = v4

draw_sprite_ext(
	s,
	iu mod max(1, sprite_get_number(s)),
	round(lj + (sprite_get_xoffset(s) - sprite_get_width(s) / 2) * tw),
	round(b4 + (sprite_get_yoffset(s) - sprite_get_height(s) / 2) * tw - 32),
	tw, tw,
	0, c_white, 1
	)

s = v5

draw_sprite_ext(
	s,
	iu mod max(1, sprite_get_number(s)),
	round(sz + (sprite_get_xoffset(s) - sprite_get_width(s) / 2) * tw),
	round(b4 + (sprite_get_yoffset(s) - sprite_get_height(s) / 2) * tw - 32),
	tw, tw,
	0, c_white, 1
	)

s = v1

draw_sprite_ext(
	s,
	iu mod max(1, sprite_get_number(s)),
	round(lj + (sprite_get_xoffset(s) - sprite_get_width(s) / 2) * tw),
	round(kv + (sprite_get_yoffset(s) - sprite_get_height(s) / 2) * tw + 32),
	tw, tw,
	0, c_white, 1
	)

s = v2

draw_sprite_ext(
	s,
	iu mod max(1, sprite_get_number(s)),
	round(sz + (sprite_get_xoffset(s) - sprite_get_width(s) / 2) * tw),
	round(kv + (sprite_get_yoffset(s) - sprite_get_height(s) / 2) * tw + 32),
	tw, tw,
	0, c_white, 1
	)
