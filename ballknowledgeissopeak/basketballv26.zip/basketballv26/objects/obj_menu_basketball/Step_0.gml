var i5 = gravty
var dp = 0.82
var yw = 0.75
var b1 = ot
var jd = 0.9
var mm = 2
var mh = ov
var jv = ou
var oa = place_meeting(x, y + 1, obj_floor)
var dn = false

vf--

j1 += 1.2 * m2

if vf <= 0 and !oa
{
	vg = true
	yp = vd
	vf = irandom_range(100, 220)
}

if vg and !oa
{
	yp = max(yp, vd)
}

yp += i5
j1 *= b1
j1 = clamp(j1, -jv, jv)

if oa
{
	j1 *= jd

	if (abs(j1) < 0.35)
	{
		j1 = 0
	}
}

if (place_meeting(x, y, obj_floor))
{
	var n8 = x
	var n9 = y
	var hx = false

	for (var r = 1; r <= 32 and !hx; r++)
	{
		for (var a = 0; a < 360; a += 45)
		{
			var nx = n8 + lengthdir_x(r, a)
			var ny = n9 + lengthdir_y(r, a)

			if (!place_meeting(nx, ny, obj_floor))
			{
				x = nx
				y = ny
				j1 = 0
				yp = 0
				hx = true
				break
			}
		}
	}

	if !hx
	{
		j1 = 0
		yp = 0
		exit
	}
}

var m3 = j1
var m4 = yp
var wc = max(1, ceil(max(abs(m3), abs(m4))))
var mx = m3 / wc
var my = m4 / wc

repeat (wc)
{
	if mx != 0
	{
		if (place_meeting(x + mx, y, obj_floor))
		{
			if (abs(j1) > 2)
			{
				za = min(abs(j1) * 0.012, 0.12)
			}

			j1 = -j1 * yw

			if (abs(j1) < 1)
			{
				j1 = 0
			}

			if j1 == 0
			{
				m2 = -m2
			}
			else
			{
				m2 = sign(j1)
			}
			mx = 0
		}
		else
		{
			x += mx
		}
	}

	if my != 0
	{
		if (place_meeting(x, y + my, obj_floor))
		{
			if my > 0
			{
				if (abs(yp) > 2)
				{
					dn = true
					v8 = min(abs(yp) * 0.012, 0.12)
				}

				var z1 = abs(yp) * dp

				if vg
				{
					u7 = min(u7 + u8, u9)
					z1 = max(u7, abs(yp) * u6)
					z1 = min(z1, u5)
					vg = false
					vb = true
				}

				if z1 < mm
				{
					yp = 0
				}
				else
				{
					yp = -z1
				}
			}
			else
			{
				yp = abs(yp) * yw

				if yp < 1
				{
					yp = 0
				}

				vg = false
			}

			my = 0
		}
		else
		{
			y += my
		}
	}
}

if dn
{
	var ya = (bbox_left + bbox_right) * 0.5
	- sprite_get_width(spr_jumpvfx) * 0.5
	+ sprite_get_xoffset(spr_jumpvfx)
	var yb = bbox_bottom + 1
	- sprite_get_bbox_bottom(spr_jumpvfx)
	+ sprite_get_yoffset(spr_jumpvfx)

	instance_create_depth(ya, yb, depth + 1, obj_jump_vfx)
}

oa = place_meeting(x, y + 1, obj_floor)

if (oa and abs(yp) < 1)
{
	vc++

	if vc >= 15
	{
		u7 = 32
	}

	sp++

	if sp >= 24
	{
		yp = -12
		sp = 0
	}
}
else
{
	vc = 0
	sp = 0
}

var wd = 0.35
var f6 = 0.22

v8 += (-v7) * wd - v8 * f6
v7 += v8
za += (-y9) * wd - za * f6
y9 += za

v9 = 1 + v7 - y9
wa = 1 - v7 + y9

image_xscale = ch
image_yscale = ch
mask_index = sprite_index
yj = ch * v9
yk = ch * wa

var vw = max(
	sprite_get_bbox_right(sprite_index) - sprite_get_bbox_left(sprite_index) + 1,
	sprite_get_bbox_bottom(sprite_index) - sprite_get_bbox_top(sprite_index) + 1
	)
var vz = max(1, vw * ch * 0.5)
vv -= (j1 / vz) * (180 / pi)

if yp < -mh
{
	yp = -mh
}

if vb and yp >= -mh
{
	vb = false
}
