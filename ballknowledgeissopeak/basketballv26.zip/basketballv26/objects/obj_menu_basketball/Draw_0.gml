draw_sprite_ext(sprite_index, image_index, x, y, yj, yk, vv, image_blend, image_alpha)
