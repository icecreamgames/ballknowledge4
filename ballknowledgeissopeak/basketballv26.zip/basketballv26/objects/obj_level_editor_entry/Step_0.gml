if (room == room_level_editor
	or room == room_main_menu
	or room == room_custom_levels
	or room == room_published_levels
	or room == room_custom_level_play)
{
	d3 = false
	mi = false
	exit
}

var jf = display_get_gui_width()
var mv = device_mouse_x_to_gui(0)
var mw = device_mouse_y_to_gui(0)
var lg = jf - 214
var xj = 18
var st = jf - 18
var dm = 66
var mj = jf - 326
var mk = jf - 226

d3 = point_in_rectangle(mv, mw, lg, xj, st, dm)

mi = point_in_rectangle(mv, mw, mj, xj, mk, dm)

if (d3 and mouse_check_button_pressed(mb_left))
{
	room_goto(room_main_menu)
	exit
}
