if (instance_number(obj_level_editor_entry) > 1)
{
	instance_destroy()
	exit
}

persistent = true
d3 = false
mi = false
