if (room == room_level_editor
	or room == room_main_menu
	or room == room_custom_levels
	or room == room_published_levels
	or room == room_custom_level_play)
{
	exit
}

var jf = display_get_gui_width()
var mv = device_mouse_x_to_gui(0)
var mw = device_mouse_y_to_gui(0)
var lg = jf - 214
var xj = 18
var st = jf - 18
var dm = 66
var dh = make_color_rgb(27, 29, 32)
var d1 = make_color_rgb(70, 73, 79)
var wo = make_color_rgb(238, 238, 238)

draw_set_font(Font1)
draw_set_halign(fa_center)
draw_set_valign(fa_middle)
ui_draw_button(lg, xj, st, dm, "Menu", d1, dh, wo, mv, mw, 2)

draw_set_halign(fa_left)
draw_set_valign(fa_top)
draw_set_alpha(1)
draw_set_color(c_white)
