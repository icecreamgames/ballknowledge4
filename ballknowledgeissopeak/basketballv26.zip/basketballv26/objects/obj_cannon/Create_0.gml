l4 = noone
image_xscale = -1
gl = 90
image_angle = gl

bv = 0.8
en = 80
eq = 1400
ep = 9
ex = 300
cg = 118
z2 = false
depth = -500
image_speed = 0
io = false
