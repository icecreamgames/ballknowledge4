if (l4 != noone and !instance_exists(l4))
{
	l4 = noone
	z2 = false
}

if l4 == noone
{
	var na = collision_circle(x, y, ex, obj_basketball, false, true)

	if na != noone and na.eo == 0 and na.ek <= 0
	{
		l4 = na
		z2 = false

		na.eo = 1
		na.bk = false
		na.vg = false
		na.j1 = 0
		na.yp = 0
		na.eu = false
		na.er = 0
		na.ev = en
		na.visible = false
		global.wx = 1
	}
}

if (l4 != noone and instance_exists(l4))
{
	var cd = l4
	var kd = keyboard_check(vk_left) or keyboard_check(ord("A"))
	var ke = keyboard_check(vk_right) or keyboard_check(ord("D"))
	var kf = keyboard_check(vk_space)
	var kg = keyboard_check_pressed(vk_space)

	if (variable_global_exists("mp"))
	kd = kd or global.mp

	if (variable_global_exists("mq"))
	ke = ke or global.mq

	if (variable_global_exists("mr"))
	kf = kf or global.mr

	if (variable_global_exists("ms"))
	kg = kg or global.ms

	if kd
	{
		gl += bv
	}

	if ke
	{
		gl -= bv
	}

	gl = clamp(gl, 15, 165)
	image_angle = gl - 90

	cd.x = x
	cd.y = y
	cd.j1 = 0
	cd.yp = 0
	cd.visible = false

	if !kf
	{
		z2 = true
	}

	if z2 and kg
	{
		image_speed = 1
		io = true
	}
}

if io and image_index == 5
{
	var cd = l4
	var ce = max(cd.bbox_right - cd.bbox_left, cd.bbox_bottom - cd.bbox_top) * 0.5
	var m6 = cg + ce + 4

	cd.x = x + lengthdir_x(m6, gl)
	cd.y = y + lengthdir_y(m6, gl)
	cd.j1 = lengthdir_x(en, gl)
	cd.yp = lengthdir_y(en, gl)
	cd.em = en
	cd.el = true
	cd.eu = true
	cd.er = 1
	cd.ev = en

	cd.visible = true
	cd.eo = 0
	cd.ek = 30
	cd.k3 = 30
	cd.k4 = 0
	cd.vg = false
	obj_basketball.ip = true
	audio_play_sound(snd_cannon, 1, false)

	var camra = instance_find(obj_camera_controller, 0)

	if camra != noone
	{
		camra.uw = max(camra.uw, eq)
		camra.ux = max(camra.ux, ep)
	}

	l4 = noone
	z2 = false
	io = false
	image_speed = 0
	image_index = 0
}
