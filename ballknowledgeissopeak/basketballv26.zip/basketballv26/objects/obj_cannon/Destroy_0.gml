if (l4 != noone and instance_exists(l4))
{
	l4.visible = true
	l4.eo = 0
	l4.ek = 15
}
