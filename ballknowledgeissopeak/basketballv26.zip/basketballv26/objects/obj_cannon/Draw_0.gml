var jm = l4 != noone and instance_exists(l4)

draw_sprite_ext(spr_cannonholder, 0, x, y, abs(image_xscale), abs(image_yscale), 0, image_blend, image_alpha)

draw_self()

if jm
{
	var ce = max(
		l4.bbox_right - l4.bbox_left + 1,
		l4.bbox_bottom - l4.bbox_top + 1
		) * 0.5
	var m6 = cg + ce + 4
	var px = x + lengthdir_x(m6, gl)
	var py = y + lengthdir_y(m6, gl)
	var vx = lengthdir_x(en, gl)
	var vy = lengthdir_y(en, gl)
	var p3 = l4.gravty
	var p2 = l4.ot
	var p5 = l4.ou
	var p9 = l4.ov
	var p1 = true

	draw_set_color(c_white)
	draw_set_alpha(0.9)

	var p4 = false

	for (var i = 0; i < 200; i++)
	{
		var iw = p5
		var ix = p9

		if p1
		{
			iw = max(iw, en)
			ix = max(ix, en)

			if (abs(vx) <= p5 and vy >= -p9)
			{
				p1 = false
				iw = p5
				ix = p9
			}
		}

		vy += p3
		vx *= p2
		vx = clamp(vx, -iw, iw)

		var p8 = max(1, ceil(max(abs(vx), abs(vy))))
		var p6 = vx / p8
		var p7 = vy / p8

		repeat (p8)
		{
			if p6 != 0
			{
				if (collision_circle(px + p6, py, ce, obj_floor, false, true) != noone)
				{
					p4 = true
					break
				}

				px += p6
			}

			if p7 != 0
			{
				if (collision_circle(px, py + p7, ce, obj_floor, false, true) != noone)
				{
					p4 = true
					break
				}

				py += p7
			}
		}

		if p4
		{
			break
		}

		if i mod 3 == 0
		{
			draw_circle(px, py, 7, false)
		}

		if vy < -ix
		{
			vy = -ix
		}
	}

}

draw_set_halign(fa_left)
draw_set_valign(fa_top)
draw_set_alpha(1)
draw_set_color(c_white)
