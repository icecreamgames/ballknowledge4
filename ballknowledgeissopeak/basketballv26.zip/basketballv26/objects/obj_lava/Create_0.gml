ld = room_height
depth = -10000
s8 = 0.5
md = 2
be = 0.001

zg = 0
ze = 8
zf = 35

k7 = make_color_rgb(255, 65, 0)
wf = make_color_rgb(255, 190, 0)

if room == room10 or room == room13 or room == room14 or room == room15
{
	s8 = 5
}

lc = 3

la = 1.5

lb = 20

k9 = 0

k8 = 0

visible = false
