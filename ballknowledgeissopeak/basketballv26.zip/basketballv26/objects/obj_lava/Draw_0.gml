draw_set_color(k7)

for (var xx = 0; xx < room_width; xx += 1)
{
	var zh = ld
	+ sin(xx / 90 + zg) * 30

	draw_rectangle(xx, zh, xx + 1, room_height, false)
}

for (var i = 0; i < 20; i++)
{
	var bx = (i * 137 + zg * 20) mod room_width
	var wg = ld
	+ sin(bx / 90 + zg) * 10

	var gg = max(1, room_height - wg)
	var by = wg + 10
	+ ((i * 73 + zg * 15) mod gg)

	draw_set_color(make_color_rgb(255, 150, 0))
	draw_circle(bx, by, 3, false)
}

draw_set_color(c_white)
