ld -= s8

ld = max(ld, 0)

zg += 0.12

var fz = variable_global_exists("f1")
and global.f1
and variable_global_exists("fw")
and global.fw
var ht = variable_global_exists("ls")
and global.ls
and variable_global_exists("lr")
and global.lr

if (!fz and !ht and instance_exists(obj_basketball))
{
	with (obj_basketball)
	{
		if eo == 0 and bbox_bottom >= other.ld
		{
			room_restart()
		}
	}
}
