var jf = display_get_gui_width()
var je = display_get_gui_height()
var mv = device_mouse_x_to_gui(0)
var mw = device_mouse_y_to_gui(0)
var lm = array_length(l0)
var mf = max(0, lm - yh)

if n3 > 0
{
	n3--

	if n3 <= 0 and l1 < 0 and ym < 0
	{
		n2 = ""
	}
}

if mouse_wheel_up()
{
	t0--
}

if mouse_wheel_down()
{
	t0++
}

t0 = clamp(t0, 0, mf)

if mf > 0
{
	var t6 = jf - 58
	var t8 = jf - 42
	var uc = 166
	var t1 = min(je - 48, 166 + yh * 104 - 16)
	var t4 = t1 - uc
	var ua = max(52, t4 * yh / lm)
	var ud = max(1, t4 - ua)
	var ub = uc + ud * t0 / mf

	if (mouse_check_button_pressed(mb_left)
		and point_in_rectangle(
		mv,
		mw,
		t6 - 7,
		uc,
		t8 + 7,
		t1
		))
	{
		scrlling = true

		if mw >= ub and mw <= ub + ua
		{
			tz = mw - ub
		}
		else
		{
			tz = ua * 0.5
		}
	}

	if (scrlling and mouse_check_button(mb_left))
	{
		var t3 = clamp((mw - tz - uc) / ud, 0, 1)
		t0 = round(t3 * mf)
	}
}
else
{
	scrlling = false
}

if (mouse_check_button_released(mb_left))
{
	scrlling = false
}

j0 = -1
jy = -1

if (mouse_check_button_pressed(mb_left))
{
	if (point_in_rectangle(mv, mw, 24, 24, 140, 76))
	{
		room_goto(room_main_menu)
		exit
	}

	if (point_in_rectangle(mv, mw, jf - 170, 24, jf - 24, 76))
	{
		published_levels_refresh()
		exit
	}

	var vr = 190
	var vk = 12
	var vq = vr * 3 + vk * 2
	var vo = (jf - vq) * 0.5

	for (var vl = 0; vl < 3; vl++)
	{
		var d4 = vo + vl * (vr + vk)

		if (point_in_rectangle(mv, mw, d4, 92, d4 + vr, 136))
		{
			if vp != vl and l1 < 0
			{
				vp = vl
				t0 = 0
				published_levels_refresh()
			}

			exit
		}
	}
}

var tb = 166
var ta = 104
var bf = 10
var oy = 92
var yo = 78
var gr = jf - 78 - yo
var x5 = gr - bf - yo
var ox = x5 - bf - oy

for (var vh = 0; vh < yh; vh++)
{
	var ka = t0 + vh

	if ka >= lm
	{
		break
	}

	var xj = tb + vh * ta
	var dm = xj + 88

	if (point_in_rectangle(mv, mw, 78, xj, jf - 78, dm))
	{
		j0 = ka
	}

	if (point_in_rectangle(mv, mw, ox, xj + 18, ox + oy, dm - 18))
	{
		jy = 0
	}
	else if (point_in_rectangle(mv, mw, x5, xj + 18, x5 + yo, dm - 18))
	{
		jy = 1
	}
	else if (point_in_rectangle(mv, mw, gr, xj + 18, gr + yo, dm - 18))
	{
		jy = 2
	}

	if (mouse_check_button_pressed(mb_left) and j0 == ka)
	{
		var un = l0[ka]

		if jy == 0
		{
			if (variable_struct_exists(un, "items")
				and is_array(un.items)
				and custom_level_has_player(un.items))
			{
				global.qp = un
				global.qn = true
				room_goto(room_custom_level_play)
			}
			else
			{
				n2 = "This level cannot be played"
				n3 = room_speed * 4
			}

			exit
		}

		if ((jy == 1 or jy == 2) and ym < 0)
		{
			n2 = "Saving vote..."
			n3 = 0
			var yn = -1

			if jy == 1
			{
				yn = 1
			}

			ym = published_level_vote(un.id, yn)

			if ym < 0
			{
				n2 = "Could not start the vote"
				n3 = room_speed * 4
			}

			exit
		}
	}
}
