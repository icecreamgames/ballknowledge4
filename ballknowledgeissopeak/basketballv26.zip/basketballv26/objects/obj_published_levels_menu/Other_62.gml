if (!ds_map_exists(async_load, "id"))
{
	exit
}

var fh = async_load[? "id"]
var kj = fh == l1
var km = fh == ym

if (!kj and !km)
{
	exit
}

if kj
{
	l1 = -1
}

if km
{
	ym = -1
}

var nb = -1
var j4 = 0
var ra = ""

if ds_map_exists(async_load, "status")
{
	nb = async_load[? "status"]
}

if ds_map_exists(async_load, "http_status")
{
	j4 = async_load[? "http_status"]
}

if ds_map_exists(async_load, "result")
{
	ra = async_load[? "result"]
}

if nb != 0 or j4 < 200 or j4 >= 300
{
	n2 = "Could not reach the published-level server"

	if j4 == 404
	{
		n2 = "Published levels are not deployed yet"
	}

	n3 = room_speed * 5
	exit
}

try
{
	var so = json_parse(ra)

	if kj
	{
		if (!is_struct(so) or !variable_struct_exists(so, "levels") or !is_array(so.levels))
		{
			n2 = "The server returned an invalid level list"
			n3 = room_speed * 5
			exit
		}

		l0 = so.levels
		t0 = clamp(t0, 0, max(0, array_length(l0) - yh))
		n2 = ""

		if array_length(l0) == 0
		{
			n2 = "No levels have been published yet"
		}

		n3 = 0
	}
	else
	{
		n2 = "Vote saved"
		n3 = room_speed * 3
		published_levels_refresh()
	}
} catch (z4)
{
	show_debug_message("Could not parse published-level response: " + string(z4))
	n2 = "The server returned invalid data"
	n3 = room_speed * 5
}
