l0 = []
vm = ["newest", "oldest", "popular"]
vn = ["Youngest first", "Oldest first", "Most popular"]
vp = 0
t0 = 0
yh = 5
scrlling = false
tz = 0
j0 = -1
jy = -1
l1 = -1
ym = -1
n2 = "Loading published levels..."
n3 = 0

published_levels_refresh()
