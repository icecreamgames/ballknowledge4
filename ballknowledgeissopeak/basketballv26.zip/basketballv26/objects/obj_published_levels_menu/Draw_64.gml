var jf = display_get_gui_width()
var je = display_get_gui_height()
var mv = device_mouse_x_to_gui(0)
var mw = device_mouse_y_to_gui(0)
var bgc = make_color_rgb(25, 27, 30)
var ok = make_color_rgb(38, 40, 44)
var ol = make_color_rgb(48, 50, 55)
var dh = make_color_rgb(27, 29, 32)
var wo = make_color_rgb(238, 238, 238)
var m5 = make_color_rgb(156, 159, 166)

draw_clear(bgc)
draw_set_font(Font1)
draw_set_halign(fa_center)
draw_set_valign(fa_middle)

ui_draw_selected_button(24, 24, 140, 76, "Back", false, mv, mw)
ui_draw_selected_button(jf - 170, 24, jf - 24, 76, "Refresh", false, mv, mw)

draw_set_color(wo)
draw_text_transformed(jf * 0.5, 48, "Published Levels", 2.0, 2.0, 0)

var vr = 190
var vk = 12
var vq = vr * 3 + vk * 2
var vo = (jf - vq) * 0.5

for (var vl = 0; vl < 3; vl++)
{
	var d4 = vo + vl * (vr + vk)
	ui_draw_selected_button(d4, 92, d4 + vr, 136, vn[vl], vp == vl, mv, mw)
}

var lm = array_length(l0)
var tb = 166
var ta = 104
var bf = 10
var oy = 92
var yo = 78
var gr = jf - 78 - yo
var x5 = gr - bf - yo
var ox = x5 - bf - oy

for (var vh = 0; vh < yh; vh++)
{
	var ka = t0 + vh

	if ka >= lm
	{
		break
	}

	var ll = l0[ka]
	var xj = tb + vh * ta
	var dm = xj + 88
	var s9 = ok

	if j0 == ka
	{
		s9 = ol
	}

	draw_set_color(s9)
	draw_rectangle(78, xj, jf - 78, dm, false)
	draw_set_color(dh)
	draw_rectangle(78, xj, jf - 78, dm, true)

	draw_set_halign(fa_left)
	draw_set_color(wo)
	var i0 = ll.name
	var u1 = i0
	var m9 = ox - 126

	while (string_width(u1) > m9 and string_length(u1) > 4)
	{
		u1 = string_delete(u1, string_length(u1), 1)
	}

	if u1 != i0
	{
		u1 += "..."
	}

	draw_text(106, xj + 29, u1)

	var b8 = "Player"
	var fo = ""
	var f7 = ""
	var x6 = 0
	var g1 = 0

	if variable_struct_exists(ll, "author_name")
	{
		b8 = ll.author_name
	}

	if variable_struct_exists(ll, "created_at")
	{
		fo = string(ll.created_at)
	}

	f7 = fo

	if string_length(fo) >= 10
	{
		f7 = string_copy(fo, 1, 10)
	}

	if variable_struct_exists(ll, "upvotes")
	{
		x6 = ll.upvotes
	}

	if variable_struct_exists(ll, "downvotes")
	{
		g1 = ll.downvotes
	}

	draw_set_color(m5)
	draw_text(106, xj + 62, "by " + b8 + "  -  " + f7 + "  -  score " + string(x6 - g1))

	draw_set_halign(fa_center)
	ui_draw_selected_button(ox, xj + 18, ox + oy, dm - 18, "Play", false, mv, mw)
	ui_draw_vote_button(x5, xj + 18, x5 + yo, dm - 18, true, x6, mv, mw)
	ui_draw_vote_button(gr, xj + 18, gr + yo, dm - 18, false, g1, mv, mw)
}

if lm > yh
{
	var t6 = jf - 58
	var t8 = jf - 42
	var uc = tb
	var t1 = min(je - 48, tb + yh * ta - 16)
	var t4 = t1 - uc
	var t7 = lm - yh
	var ua = max(52, t4 * yh / lm)
	var ub = uc
	+ (t4 - ua) * t0 / t7
	var t9 = ub + ua
	var t5 = point_in_rectangle(
		mv,
		mw,
		t6 - 5,
		ub,
		t8 + 5,
		t9
		)

	draw_set_color(dh)
	draw_rectangle(t6, uc, t8, t1, false)
	draw_set_color(make_color_rgb(53, 56, 62))
	draw_rectangle(t6 + 3, uc + 3, t8 - 3, t1 - 3, false)
	var t2 = make_color_rgb(110, 116, 126)

	if t5 or scrlling
	{
		t2 = make_color_rgb(67, 139, 171)
	}

	draw_set_color(t2)
	draw_rectangle(t6, ub, t8, t9, false)
	draw_set_color(wo)
	draw_triangle(t6, uc - 8, t8, uc - 8, (t6 + t8) * 0.5, uc - 17, false)
	draw_triangle(t6, t1 + 8, t8, t1 + 8, (t6 + t8) * 0.5, t1 + 17, false)
}

if (string_length(n2) > 0)
{
	var n4 = je - 38

	if lm == 0
	{
		n4 = je * 0.5
	}

	draw_set_halign(fa_center)
	draw_set_color(m5)
	draw_text(jf * 0.5, n4, n2)
}

draw_set_halign(fa_left)
draw_set_valign(fa_top)
draw_set_alpha(1)
draw_set_color(c_white)
