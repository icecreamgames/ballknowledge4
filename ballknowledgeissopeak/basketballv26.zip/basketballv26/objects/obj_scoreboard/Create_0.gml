ee = [
	room_tut1_1,
	room2,
	room3,
	room4,
	room5,
	room6,
	room7,
	room8,
	room9,
	room10,
	room11,
	room12,
	room13,
	room14,
	room15
	]

ed = array_length(ee)

hr = 3
hm = room_width * 0.5 - 230
ho = room_height * 0.5 + 72
hn = room_width * 0.5 + 230
hl = ho + 68

oc = function()
{
	global.lo = -1
	global.lq = room_main_menu
	room_goto(room_level_editor)
}

i4 = function()
{
	if (floor(global.ty) == hr)
	{
		oc()
		return
	}

	var np = max(0, floor(global.ty))

	if np < ed
	{
		room_goto(ee[np])
	}
}
