if (floor(global.ty) == hr
	and mouse_check_button_pressed(mb_left)
	and point_in_rectangle(
	mouse_x,
	mouse_y,
	hm,
	ho,
	hn,
	hl
	))
{
	oc()
}
