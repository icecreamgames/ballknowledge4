if (floor(global.ty) != hr
	or point_in_rectangle(
	mouse_x,
	mouse_y,
	hm,
	ho,
	hn,
	hl
	))
{
	i4()
}
