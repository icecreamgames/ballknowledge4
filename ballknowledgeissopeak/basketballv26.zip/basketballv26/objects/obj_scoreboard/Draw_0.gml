draw_self()
draw_set_font(Font1)
draw_set_color(c_white)
draw_set_alpha(1)

if (floor(global.ty) == hr)
{
	draw_set_halign(fa_center)
	draw_set_valign(fa_middle)

	draw_text_transformed(room_width * 0.5, room_height * 0.5 - 58, "Now try making your own!", 3, 3, 0)

	ui_draw_button(
		hm,
		ho,
		hn,
		hl,
		"OPEN LEVEL EDITOR",
		make_color_rgb(70, 73, 79),
		make_color_rgb(27, 29, 32),
		make_color_rgb(238, 238, 238),
		mouse_x,
		mouse_y,
		2
		)

	draw_set_halign(fa_left)
	draw_set_valign(fa_top)
}
else if global.ty < ed
{
	draw_text_transformed(x - 300, y, "You Beat Level:", 5, 5, 0)

	draw_text_transformed(x+370, y, string(global.ty), 5, 5, 0)

	draw_text_transformed(x - 300, y+300, "Press (ANY KEY) to go to the next level.", 3, 3, 0)
}
else
{
	draw_text_transformed(x - 300, y, "YOU BEAT THE GAME", 5, 5, 0)
}

draw_set_halign(fa_left)
draw_set_valign(fa_top)
draw_set_alpha(1)
draw_set_color(c_white)
