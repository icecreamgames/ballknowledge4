if (room == room_level_editor
	and instance_exists(obj_level_editor_controller)
	and obj_level_editor_controller.mu == 0)
{
	exit
}

depth = 99

draw_clear(make_color_rgb(25, 27, 30))

var c6 = spr_new_brick
var cv = sprite_get_bbox_left(c6)
var c0 = sprite_get_bbox_top(c6)
var c1 = sprite_get_bbox_right(c6) - cv + 1
var cu = sprite_get_bbox_bottom(c6) - c0 + 1
var cw = cv - sprite_get_xoffset(c6)
var cz = c0 - sprite_get_yoffset(c6)
var c7 = max(1, c1 - 35)
var c8 = max(1, cu - 22)
var dc = camera_get_view_x(d8)
var dd = camera_get_view_y(d8)
var db = dc + camera_get_view_width(d8)
var da = dd + camera_get_view_height(d8)
var c2 = floor((dc - cw) / c7) * c7
var c3 = floor((dd - cz) / c8) * c8
var c4 = db - cw
var c5 = da - cz
var c9 = make_color_rgb(105, 105, 105)

for (var de = c2; de <= c4; de += c7)
{
	for (var df = c3; df <= c5; df += c8)
	{
		draw_sprite_ext(c6, 0, de, df, 1, 1, 0, c9, 0.78)
	}
}
