depth = 99

d8 = view_camera[0]

ns = camera_get_view_width(d8)
nq = camera_get_view_height(d8)

ec = 1

ir = camera_get_view_x(d8) + ns / 2
z3 = camera_get_view_y(d8) + nq / 2

uw = 0
ux = 0

zm = 5000

ew = 1.5

zp = 5.05

zn = 0.12

zo = 0.25

zq = 0.065

it = 0.16
