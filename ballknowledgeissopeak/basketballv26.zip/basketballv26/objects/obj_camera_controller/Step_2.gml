if (!instance_exists(obj_basketball))
{
	exit
}

var cd = instance_find(obj_basketball, 0)
var wm = 1
var zr = zq
var ej = cd.eo == 1

if cd.bk or ej
{
	wm = zm
	zr = zn
}
else if cd.k4 > 0
{
	wm = zp
	zr = zo
}

var me = max(1, min(room_width / ns, room_height / nq))

var b2 = me

if ej
{
	b2 = me * ew
}

wm = min(wm, b2)

ec = lerp(ec, wm, zr)

if (abs(ec - wm) < 0.001)
{
	ec = wm
}

var yd = ns * ec
var yc = nq * ec

camera_set_view_size(d8, yd, yc)

var bi = 0
var bj = 0

if cd.bk
{
	bi = clamp(cd.bn * 0.40, -100, 100)

	bj = clamp(cd.bo * 0.25, -60, 60)
}
else
{
	bi = clamp(cd.j1 * 3, -60, 60)

	bj = clamp(cd.yp * 2, -40, 40)
}

ir = lerp(ir, cd.x + bi, it)

z3 = lerp(z3, cd.y + bj, it)

var ea = ir - yd / 2
var eb = z3 - yc / 2

if room_width >= yd
{
	ea = clamp(ea, 0, room_width - yd)
}
else
{
	ea = (room_width - yd) / 2
}

if room_height >= yc
{
	eb = clamp(eb, 0, room_height - yc)
}
else
{
	eb = (room_height - yc) / 2
}

if ux > 0
{
	ea += random_range(-uw, uw)
	eb += random_range(-uw, uw)

	uw *= 0.78
	ux--

	if ux <= 0
	{
		uw = 0
	}
}

camera_set_view_pos(d8, ea, eb)

if (instance_exists(obj_tutorial3) and instance_exists(obj_basketball))
{
	if obj_tutorial3.xy
	{

		var xp = instance_find(obj_basketball, 0)
		var xq = view_camera[0]
		var xs = camera_get_view_width(xq)
		var xr = camera_get_view_height(xq)
		var xt = xp.x - xs / 2
		var xu = xp.y - xr / 2

		xt = clamp(xt, 0, max(0, room_width - xs))

		xu = clamp(xu, 0, max(0, room_height - xr))

		camera_set_view_pos(xq, xt, xu)
	}
}

if (instance_exists(obj_lava))
{
	var qy = instance_find(obj_lava, 0)

	if qy.k9 == 1
	{

		var qw = view_camera[0]
		var q2 = camera_get_view_width(qw)
		var qx = camera_get_view_height(qw)
		var qu = camera_get_view_x(qw)
		var qv = camera_get_view_y(qw)

		if (instance_exists(obj_basketball))
		{
			var qt = instance_find(obj_basketball, 0)

			qu = clamp(qt.x - q2 / 2, 0, max(0, room_width - q2))

			qv = clamp(qt.y - qx / 2, 0, max(0, room_height - qx))
		}

		var q1 = qy.lb
		var qz = random_range(-q1, q1)

		var q0 = random_range(-q1, q1)

		camera_set_view_pos(qw, round(qu + qz), round(qv + q0))
	}
}
