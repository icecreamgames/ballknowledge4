var cx = display_get_gui_width() * 0.5
var gh = display_get_gui_height()
var b4 = gh - 115
var kv = gh - 55
var lj = cx - 65
var sz = cx + 65
var tw = 2
var iu = floor(current_time / 500)
var li = sprite_left
var sv = sprite_right
var bd = sprite_a
var f5 = sprite_d
var vu = spr_space

if keyboard_check(vk_left)
{
	li = sprite_left_pressed
}

if keyboard_check(vk_right)
{
	sv = sprite_right_pressed
}

if keyboard_check(ord("A"))
{
	bd = sprite_a_pressed
}

if keyboard_check(ord("D"))
{
	f5 = sprite_d_pressed
}

if keyboard_check(vk_space)
{
	vu = spr_space_selected
}

ui_draw_key(li, lj, b4 - 32, tw, iu)
ui_draw_key(sv, sz, b4 - 32, tw, iu)
ui_draw_key(bd, lj, kv + 32, tw, iu)
ui_draw_key(f5, sz, kv + 32, tw, iu)
ui_draw_key(vu, cx + 250, gh - 85, 3, iu)
