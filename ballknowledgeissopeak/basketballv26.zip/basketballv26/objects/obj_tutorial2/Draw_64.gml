var cx = display_get_gui_width() / 2
var gh = display_get_gui_height()
var cy = gh - 115
var tw = 2
var i2 = 10
var gz = 250
var g0 = 100
var gu = 250
var gv = 100
var tk = 260
var tl = 100
var ti = 260
var tj = 100
var iu = floor(current_time / 500)
var gq = keyboard_check(vk_down)
var tf = keyboard_check(ord("S"))
var v3 = sprite_down
var v6 = sprite_s
var gs = gz
var gt = g0
var tg = tk
var th = tl

if gq
{
	v3 = sprite_down_pressed

	gs = gu
	gt = gv
}

if tf
{
	v6 = sprite_s_pressed

	tg = ti
	th = tj
}

var w1 = sprite_get_width(sprite_down) * tw
var w2 = sprite_get_width(sprite_s_pressed) * tw
var xl = w1 + i2 + w2
var x1 = cx - xl / 2 + w1 / 2
var x2 = cx + xl / 2 - w2 / 2
var go = round(x1 + (sprite_get_xoffset(sprite_down) - sprite_get_width(sprite_down) / 2) * tw)

var gp = round(cy + (sprite_get_yoffset(sprite_down) - sprite_get_height(sprite_down) / 2) * tw)

var td = round(x2 + (sprite_get_xoffset(sprite_s) - sprite_get_width(sprite_s) / 2) * tw)

var te = round(cy + (sprite_get_yoffset(sprite_s) - sprite_get_height(sprite_s) / 2) * tw)

draw_sprite_ext(
	v3,
	iu mod max(1, sprite_get_number(v3)),

	go + gs,
	gp + gt,

	tw,
	tw,
	0,
	c_white,
	1
	)

draw_sprite_ext(
	v6,
	iu mod max(1, sprite_get_number(v6)),

	td + tg,
	te + th,

	tw,
	tw,
	0,
	c_white,
	1
	)
