sq += delta_time / 1000000

if sq >= 20
{
	sr = true
}

if xw and !xy and !xv
{
	xw = false
	xy = true

	e2 = 0
	e1 = false

	global.wx = 1
}

if xy
{
	if !e1
	{
		var iy = sprite_get_number(spr_clip)
		var bh = sprite_get_speed(spr_clip)

		if (sprite_get_speed_type(spr_clip) == spritespeed_framespersecond)
		{
			bh /= max(1, game_get_speed(gamespeed_fps))
		}

		if bh <= 0
		{
			bh = 12 / max(1, game_get_speed(gamespeed_fps))
		}

		e2 += bh

		if e2 >= iy
		{
			e2 = max(0, iy - 1)
			e1 = true
		}
	}

	if (e1 and keyboard_check_pressed(vk_enter))
	{
		xy = false
		xv = true
		global.wx = 1
	}
}
