var gw = display_get_gui_width()
var gh = display_get_gui_height()

if xy
{
	var mb = 12
	var e4 = min(gw * 0.5, gh * 0.5 * (800 / 454))

	var e3 = e4 * (454 / 800)
	var e5 = gw - e4 - mb
	var e6 = mb
	var wt = e6 + e3
	var ey = e5 + e4 / 2
	var wq = min(1, e4 / 400)

	draw_set_color(c_black)
	draw_set_alpha(0.85)

	draw_rectangle(e5 - 5, e6 - 5, e5 + e4 + 5, wt + 85, false)

	draw_set_alpha(1)

	draw_sprite_stretched(spr_clip, floor(e2), e5, e6, e4, e3)

	draw_set_font(-1)
	draw_set_halign(fa_center)
	draw_set_valign(fa_middle)
	draw_set_color(c_white)

	draw_text_transformed(ey, wt + 20, "HOLD SPACE MIDAIR TO AIM", wq, wq, 0)

	draw_text_transformed(ey, wt + 43, "ARROW KEYS OR A/D TO AIM", wq, wq, 0)

	if e1
	{
		draw_set_color(c_yellow)

		draw_text_transformed(ey, wt + 68, "PRESS ENTER TO CONTINUE", wq, wq, 0)
	}
}

var q5 = 2
var i2 = 12
var ml = "to restart level"

draw_set_font(-1)
draw_set_halign(fa_left)
draw_set_valign(fa_top)
draw_set_color(c_white)

var wq = 1
var q6 = sprite_get_width(spr_r) * q5
var q4 = sprite_get_height(spr_r) * q5
var wr = string_width(ml) * wq
var wp = string_height(ml) * wq
var xl = q6 + i2 + wr
var wb = (gw - xl) / 2
var ez = gh - 65
var q7 = wb
var q8 = ez - q4 / 2
var ws = wb + q6 + i2
var wt = ez - wp / 2
var q3 = floor(current_time / 500)
mod max(1, sprite_get_number(spr_r))

draw_sprite_ext(
	spr_r,
	q3,
	round(q7 + sprite_get_xoffset(spr_r) * q5),
	round(q8 + sprite_get_yoffset(spr_r) * q5),
	q5,
	q5,
	0,
	c_white,
	1
	)

draw_text_transformed(round(ws), round(wt), ml, wq, wq, 0)

draw_set_color(c_white)
draw_set_alpha(1)
draw_set_halign(fa_left)
draw_set_valign(fa_top)
