xw = false

xy = false
xv = false

e2 = 0
e1 = false
ow = false

sq = 0
sr = true
