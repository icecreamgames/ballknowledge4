if (instance_exists(obj_basketball) and x8)
{
	obj_basketball.k5 = 100000000000000000000000000000
}
