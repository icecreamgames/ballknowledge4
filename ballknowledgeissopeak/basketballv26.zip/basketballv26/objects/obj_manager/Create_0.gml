x8 = false
