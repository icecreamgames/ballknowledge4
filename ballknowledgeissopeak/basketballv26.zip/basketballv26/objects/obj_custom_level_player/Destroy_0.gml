global.f1 = false
global.fw = false
global.qn = false
global.wx = 1
global.ty = tv
