var jf = display_get_gui_width()
var je = display_get_gui_height()
var mv = device_mouse_x_to_gui(0)
var mw = device_mouse_y_to_gui(0)

if l2
{
	room_goto(ss)
	exit
}

if (mouse_check_button_pressed(mb_left))
{
	if (point_in_rectangle(mv, mw, 18, 18, 218, 70))
	{
		room_goto(ss)
		exit
	}

	if (point_in_rectangle(mv, mw, jf - 174, 18, jf - 18, 70))
	{
		room_restart()
		exit
	}

	if global.fw
	{
		var om = jf * 0.5 - 245
		var on = jf * 0.5 + 245
		var xj = je * 0.5 + 42

		if (point_in_rectangle(mv, mw, om + 24, xj, jf * 0.5 - 8, xj + 58))
		{
			room_restart()
			exit
		}

		if (point_in_rectangle(mv, mw, jf * 0.5 + 8, xj, on - 24, xj + 58))
		{
			room_goto(ss)
			exit
		}
	}
}
