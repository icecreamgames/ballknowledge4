custom_levels_load()

global.f1 = true
global.fw = false
tv = global.ty
lu = "Custom level"
l2 = false
pn = variable_global_exists("qn")
and global.qn
ss = room_custom_levels

if pn
{
	ss = room_published_levels
}

var lt = -1
var ll = undefined

if (pn
	and variable_global_exists("qp")
	and is_struct(global.qp))
{
	ll = global.qp
}
else if (variable_global_exists("f0"))
{
	lt = global.f0
}

if (!pn and lt >= 0 and lt < array_length(global.f2))
{
	ll = global.f2[lt]
}

if (!is_struct(ll) or !variable_struct_exists(ll, "items") or !is_array(ll.items))
{
	l2 = true
}
else
{
	lu = ll.name

	for (var i = 0; i < array_length(ll.items); i++)
	{
		var kn = ll.items[i]
		var n7 = obj_floor

		switch (kn.kind)
		{
			case 0:
				n7 = obj_floor
				break

			case 1:
				n7 = obj_pickup
				break

			case 2:
				n7 = obj_rim
				break

			case 3:
				n7 = obj_basketball
				break

			case 4:
				n7 = obj_cannon
				break

			case 5:
				n7 = obj_acid
				break
		}

		var fo = instance_create_layer(kn.x, kn.y, "Instances", n7)
		fo.image_xscale = kn.sx

		if kn.kind == 4
		{
			fo.image_xscale = -abs(kn.sx)
		}

		fo.image_yscale = kn.sy
		fo.image_angle = kn.rotation
	}

	instance_create_layer(0, 0, "Instances", obj_camera_controller)
}
