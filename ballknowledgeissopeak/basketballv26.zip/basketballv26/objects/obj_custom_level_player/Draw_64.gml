var jf = display_get_gui_width()
var je = display_get_gui_height()
var mv = device_mouse_x_to_gui(0)
var mw = device_mouse_y_to_gui(0)
var ok = make_color_rgb(38, 40, 44)
var dh = make_color_rgb(27, 29, 32)
var wo = make_color_rgb(238, 238, 238)

draw_set_font(Font1)
draw_set_halign(fa_center)
draw_set_valign(fa_middle)

ui_draw_menu_button(18, 18, 218, 70, "Levels", mv, mw)
ui_draw_menu_button(jf - 174, 18, jf - 18, 70, "Restart", mv, mw)

if global.fw
{
	var om = jf * 0.5 - 245
	var on = jf * 0.5 + 245
	var oo = je * 0.5 - 125
	var oj = je * 0.5 + 125

	draw_set_alpha(0.48)
	draw_set_color(c_black)
	draw_rectangle(0, 0, jf, je, false)

	draw_set_alpha(1)
	draw_set_color(ok)
	draw_rectangle(om, oo, on, oj, false)
	draw_set_color(dh)
	draw_rectangle(om, oo, on, oj, true)

	draw_set_color(wo)
	draw_text_transformed(jf * 0.5, oo + 78, "Complete", 2.2, 2.2, 0)

	var d6 = je * 0.5 + 42
	ui_draw_menu_button(om + 24, d6, jf * 0.5 - 8, d6 + 58, "Restart", mv, mw)
	ui_draw_menu_button(jf * 0.5 + 8, d6, on - 24, d6 + 58, "Levels", mv, mw)
}

draw_set_halign(fa_left)
draw_set_valign(fa_top)
draw_set_alpha(1)
draw_set_color(c_white)
