var jf = display_get_gui_width()
var je = display_get_gui_height()
var mv = device_mouse_x_to_gui(0)
var mw = device_mouse_y_to_gui(0)
var xi = make_color_rgb(38, 40, 44)
var d1 = make_color_rgb(70, 73, 79)
var dh = make_color_rgb(27, 29, 32)
var wo = make_color_rgb(238, 238, 238)
var m5 = make_color_rgb(156, 159, 166)

draw_set_font(Font1)
draw_set_halign(fa_center)
draw_set_valign(fa_middle)

if mu == 1
{
	if global.lr
	{
		var fe = jf * 0.5 - 245
		var ff = jf * 0.5 + 245
		var fg = je * 0.5 - 125
		var fb = je * 0.5 + 125
		var fd = je * 0.5 + 42

		draw_set_alpha(0.48)
		draw_set_color(c_black)
		draw_rectangle(0, 0, jf, je, false)

		draw_set_alpha(1)
		draw_set_color(xi)
		draw_rectangle(fe, fg, ff, fb, false)
		draw_set_color(dh)
		draw_rectangle(fe, fg, ff, fb, true)
		draw_set_color(wo)
		draw_text_transformed(jf * 0.5, fg + 78, "Complete", 2.2, 2.2, 0)

		ui_draw_toggle_button(
			fe + 24,
			fd,
			jf * 0.5 - 8,
			fd + 58,
			"KEEP EDITING",
			false,
			mv,
			mw
			)
		ui_draw_toggle_button(
			jf * 0.5 + 8,
			fd,
			ff - 24,
			fd + 58,
			"SAVE",
			false,
			mv,
			mw
			)

		if (wz > 0 and string_length(wy) > 0)
		{
			draw_set_color(m5)
			draw_text(jf * 0.5, je * 0.5 + 10, wy)
		}
	}
	else
	{
		draw_set_alpha(0.98)
		ui_draw_toggle_button(18, 18, 138, 66, "TEST", false, mv, mw)

		var ca = jf - 166
		var cc = 18
		var cb = jf - 18
		var b9 = 70
		ui_draw_toggle_button(ca, cc, cb, b9, "EDIT", false, mv, mw)
	}

	draw_set_halign(fa_left)
	draw_set_valign(fa_top)
	draw_set_alpha(1)
	draw_set_color(c_white)
	exit
}

draw_set_alpha(0.99)
draw_set_color(xi)
draw_rectangle(0, 0, jf, 112, false)
draw_set_color(dh)
draw_rectangle(0, 110, jf, 112, false)

ui_draw_toggle_button(12, 18, 78, 70, "BACK", false, mv, mw)

for (var xf = 0; xf < array_length(xc); xf++)
{
	var xb = xc[xf]
	var xd = 86 + xf * 94
	var xe = xd + 86
	var w9 = (xd + xe) * 0.5
	var xg = ks(xb)
	var w6 = sprite_get_bbox_left(xg)
	var w7 = sprite_get_bbox_right(xg)
	var w8 = sprite_get_bbox_top(xg)
	var w3 = sprite_get_bbox_bottom(xg)
	var vt = max(1, w7 - w6 + 1)
	var vs = max(1, w3 - w8 + 1)
	var j8 = min(30 / vt, 23 / vs)
	var j9 = j8

	if xb == 4
	{
		j9 = -j8
	}

	var w4 = (w6 + w7 + 1) * 0.5
	var w5 = (w8 + w3 + 1) * 0.5
	var j6 = w9
	- (w4 - sprite_get_xoffset(xg)) * j9
	var j7 = 32.5
	- (w5 - sprite_get_yoffset(xg)) * j8
	var w0 = uv == xb
	var xa = ui_draw_toggle_button(xd, 18, xe, 70, "", w0, mv, mw)
	var xh = 1

	if xa
	{
		xh = 1.08
	}

	draw_set_alpha(1)
	draw_sprite_ext(xg, 0, j6, j7, j9, j8, 0, c_white, 1)
	ui_draw_outlined_text(w9, 59, kq(xb), xh, wo, c_black)
}

ui_draw_toggle_button(556, 18, 630, 70, "DEL", false, mv, mw)
ui_draw_toggle_button(638, 18, 712, 70, "CLEAR", false, mv, mw)
ui_draw_toggle_button(720, 18, 764, 70, "-", false, mv, mw)
ui_draw_toggle_button(772, 18, 816, 70, "+", false, mv, mw)
ui_draw_toggle_button(824, 18, 910, 70, "SAVE", false, mv, mw)
ui_draw_toggle_button(jf - 166, 18, jf - 18, 70, "PLAY", false, mv, mw)
ui_draw_toggle_button(556, 77, 650, 104, "RENAME", false, mv, mw)
ui_draw_toggle_button(950, 77, 1024, 104, "UNDO", array_length(x4) > 0, mv, mw)
ui_draw_toggle_button(1032, 77, 1110, 104, "REDO", array_length(re) > 0, mv, mw)

draw_set_halign(fa_left)
draw_set_valign(fa_top)
draw_set_color(wo)
var u0 = ft
var lw = 526

while (string_width(u0) > lw and string_length(u0) > 4)
{
	u0 = string_delete(u0, string_length(u0), 1)
}

if u0 != ft
{
	u0 += "..."
}

draw_text(12, 82, u0)

draw_set_halign(fa_right)
draw_set_color(m5)
draw_text(932, 82, string(round(100 / hu)) + "%")

if (um >= 0 and um < array_length(kt))
{
	var ue = kt[um]
	var ul = kp(ue)
	var gi = kq(ue.kind)
	+ "   "
	+ string(round(ul.right - ul.left))
	+ " x "
	+ string(round(ul.bottom - ul.top))
	var uu = ks(ue.kind)
	var ui = sprite_get_bbox_left(uu)
	var uj = sprite_get_bbox_right(uu)
	var uk = sprite_get_bbox_top(uu)
	var uf = sprite_get_bbox_bottom(uu)
	var ut = max(1, uj - ui + 1)
	var us = max(1, uf - uk + 1)
	var uq = min(30 / ut, 26 / us)
	var ur = uq

	if ue.kind == 4
	{
		ur = -uq
	}

	var ug = (ui + uj + 1) * 0.5
	var uh = (uk + uf + 1) * 0.5
	var uo = 49
	- (ug - sprite_get_xoffset(uu)) * ur
	var up = je - 44
	- (uh - sprite_get_yoffset(uu)) * uq

	draw_set_halign(fa_left)
	draw_set_valign(fa_middle)
	draw_set_alpha(0.98)
	draw_set_color(xi)
	draw_rectangle(18, je - 66, 314, je - 22, false)
	draw_set_color(dh)
	draw_rectangle(18, je - 66, 314, je - 22, true)
	draw_sprite_ext(
		uu,
		0,
		uo,
		up,
		ur,
		uq,
		0,
		c_white,
		1
		)
	draw_set_color(wo)
	draw_text(76, je - 44, gi)
}

if (wz > 0 and string_length(wy) > 0)
{
	draw_set_halign(fa_center)
	draw_set_valign(fa_middle)
	draw_set_alpha(min(1, wz / 16))
	draw_set_color(d1)
	draw_rectangle(jf * 0.5 - 112, je - 63, jf * 0.5 + 112, je - 25, false)
	draw_set_color(dh)
	draw_rectangle(jf * 0.5 - 112, je - 63, jf * 0.5 + 112, je - 25, true)
	draw_set_color(wo)
	draw_text(jf * 0.5, je - 44, wy)
}

if rf
{
	var rv = jf * 0.5 - 350
	var rw = jf * 0.5 + 350
	var rz = je * 0.5 - 145
	var ru = je * 0.5 + 140
	var rq = rv + 32
	var rr = rw - 32
	var rs = je * 0.5 - 28
	var rp = je * 0.5 + 24
	var ri = je * 0.5 + 72

	draw_set_alpha(0.58)
	draw_set_color(c_black)
	draw_rectangle(0, 0, jf, je, false)

	draw_set_alpha(1)
	draw_set_color(xi)
	draw_rectangle(rv, rz, rw, ru, false)
	draw_set_color(dh)
	draw_rectangle(rv, rz, rw, ru, true)

	draw_set_halign(fa_center)
	draw_set_valign(fa_middle)
	draw_set_color(wo)
	var r5 = "Rename Level"

	if p0
	{
		r5 = "Level Saved"
	}

	draw_text_transformed(
		jf * 0.5,
		rz + 56,
		r5,
		1.5,
		1.5,
		0
		)

	draw_set_color(make_color_rgb(25, 27, 30))
	draw_rectangle(rq, rs, rr, rp, false)
	draw_set_color(dh)
	draw_rectangle(rq, rs, rr, rp, true)

	var u3 = r4

	while (string_width(u3 + "|")
		> rr - rq - 24
		and string_length(u3) > 0)
	{
		u3 = string_delete(u3, 1, 1)
	}

	if ((current_time div 500) mod 2 == 0)
	{
		u3 += "|"
	}

	draw_set_halign(fa_left)
	draw_set_color(wo)
	draw_text(rq + 12, (rs + rp) * 0.5, u3)

	if (string_length(renme) > 0)
	{
		draw_set_halign(fa_center)
		draw_set_color(m5)
		draw_text(jf * 0.5, je * 0.5 + 47, renme)
	}

	if p0
	{
		var pp = 8
		var pr = rv + 32
		var ps = rw - 32
		var pq = (ps - pr - pp * 2) / 3
		var pt = pr + pq
		var pw = pt + pp
		var pz = pw + pq
		var pv = pz + pp
		var pu = "PUBLISH"

		if publsh >= 0
		{
			pu = "PUBLISHING..."
		}
		else if (hk >= 0
			and hk < array_length(global.f2)
			and variable_struct_exists(
			global.f2[hk],
			"published_id"
			))
		{
			pu = "UPDATE"
		}

		ui_draw_toggle_button(
			pr,
			ri,
			pt,
			ri + 48,
			"DONE",
			false,
			mv,
			mw
			)
		ui_draw_toggle_button(
			pw,
			ri,
			pz,
			ri + 48,
			"RENAME",
			false,
			mv,
			mw
			)
		ui_draw_toggle_button(
			pv,
			ri,
			ps,
			ri + 48,
			pu,
			publsh >= 0,
			mv,
			mw
			)
	}
	else
	{
		ui_draw_toggle_button(
			rv + 32,
			ri,
			jf * 0.5 - 8,
			ri + 48,
			"CANCEL",
			false,
			mv,
			mw
			)
		ui_draw_toggle_button(
			jf * 0.5 + 8,
			ri,
			rw - 32,
			ri + 48,
			"SAVE",
			false,
			mv,
			mw
			)
	}
}

if ia
{
	var h7 = jf * 0.5 - 330
	var h8 = jf * 0.5 + 330
	var h9 = je * 0.5 - 105
	var h6 = je * 0.5 + 110
	var h1 = je * 0.5 + 36
	var h3 = h7 + 32
	var h4 = h8 - 32
	var h0 = 8
	var h2 = (h4 - h3 - h0 * 2) / 3
	var h5 = h3 + h2
	var ie = h5 + h0
	var ig = ie + h2
	var ib = ig + h0

	draw_set_alpha(0.58)
	draw_set_color(c_black)
	draw_rectangle(0, 0, jf, je, false)

	draw_set_alpha(1)
	draw_set_color(xi)
	draw_rectangle(h7, h9, h8, h6, false)
	draw_set_color(dh)
	draw_rectangle(h7, h9, h8, h6, true)

	draw_set_halign(fa_center)
	draw_set_valign(fa_middle)
	draw_set_color(wo)
	draw_text_transformed(jf * 0.5, h9 + 64, "Save before leaving?", 1.5, 1.5, 0)

	if (string_length(ic) > 0)
	{
		draw_set_color(m5)
		draw_text(jf * 0.5, je * 0.5 + 8, ic)
	}

	ui_draw_toggle_button(
		h3,
		h1,
		h5,
		h1 + 48,
		"CANCEL",
		false,
		mv,
		mw
		)
	ui_draw_toggle_button(
		ie,
		h1,
		ig,
		h1 + 48,
		"DON'T SAVE",
		false,
		mv,
		mw
		)
	ui_draw_toggle_button(
		ib,
		h1,
		h4,
		h1 + 48,
		"SAVE",
		false,
		mv,
		mw
		)
}

draw_set_halign(fa_left)
draw_set_valign(fa_top)
draw_set_alpha(1)
draw_set_color(c_white)
