global.ln = true
global.ls = false
global.lp = false
global.lr = false

if (!variable_global_exists("ty"))
{
	global.ty = 0
}

mu = 0
uv = 0
xc = [0, 2, 3, 4, 5]
um = -1
hd = false
g8 = 0
g9 = 0
hb = 0
hc = 0
g5 = false
sn = false
sf = 0
sg = 0
sb = 0
sc = 0
sl = 0
sm = 0
si = false
op = false
k0 = 0
k1 = 0

vi = true
i6 = 16
kt = []
wn = []
x4 = []
re = []
jo = 100

y4 = 35
y5 = 22

wy = ""
wz = 0

d8 = view_camera[0]
cj = 2732
ci = 1536
hu = 100 / 54
hp = 0
hq = max(0, room_height - ci)

camera_set_view_size(d8, cj, ci)
camera_set_view_pos(d8, hp, hq)

tv = global.ty
hk = -1
ft = "Untitled level"
lv = false
rf = false
r4 = ""
renme = ""
p0 = false
publsh = -1
qs = ""
ia = false
ic = ""
custom_levels_load()

ks = function(an)
{
	switch (an)
	{
		case 0: return object_get_sprite(obj_floor)
		case 1: return object_get_sprite(obj_pickup)
		case 2: return object_get_sprite(obj_rim)
		case 3: return object_get_sprite(obj_basketball)
		case 4: return object_get_sprite(obj_cannon)
		case 5: return object_get_sprite(obj_acid)
	}

	return -1
}

kq = function(an)
{
	switch (an)
	{
		case 0: return "Floor"
		case 1: return "Pickup"
		case 2: return "Rim"
		case 3: return "Player"
		case 4: return "Cannon"
		case 5: return "Acid"
	}

	return "ITEM"
}

kr = function(an)
{
	switch (an)
	{
		case 0: return obj_floor
		case 1: return obj_pickup
		case 2: return obj_rim
		case 3: return obj_basketball
		case 4: return obj_cannon
		case 5: return obj_acid
	}

	return noone
}

vj = function(bb)
{
	return round(bb / i6) * i6
}

kp = function(al)
{
	var v0 = ks(al.kind)
	var zk = sprite_get_xoffset(v0)
	var zl = sprite_get_yoffset(v0)

	if al.kind == 0
	{
		var cn = sprite_get_bbox_right(v0) - sprite_get_bbox_left(v0) + 1
		var cm = sprite_get_bbox_bottom(v0) - sprite_get_bbox_top(v0) + 1
		var fa = max(1, ceil(abs(al.sx)))
		var tc = max(1, ceil(abs(al.sy)))
		var wv = max(1, cn - y4)
		var ww = max(1, cm - y5)

		return
		{
			left: al.x + sprite_get_bbox_left(v0) - zk,
			top: al.y + sprite_get_bbox_top(v0) - zl,
			right: al.x + sprite_get_bbox_right(v0) + 1 - zk + (fa - 1) * wv,
			bottom: al.y + sprite_get_bbox_bottom(v0) + 1 - zl + (tc - 1) * ww
		}
	}

	var hg = al.sx

	if al.kind == 4
	{
		hg = -abs(al.sx)
	}

	var x1 = al.x + (sprite_get_bbox_left(v0) - zk) * hg
	var x2 = al.x + (sprite_get_bbox_right(v0) + 1 - zk) * hg
	var y1 = al.y + (sprite_get_bbox_top(v0) - zl) * al.sy
	var y2 = al.y + (sprite_get_bbox_bottom(v0) + 1 - zl) * al.sy

	return
	{
		left: min(x1, x2),
		top: min(y1, y2),
		right: max(x1, x2),
		bottom: max(y1, y2)
	}
}

oe = function(an, ae, af, a4, a5)
{
	var v0 = ks(an)

	if an == 0
	{
		var cn = sprite_get_bbox_right(v0) - sprite_get_bbox_left(v0) + 1
		var cm = sprite_get_bbox_bottom(v0) - sprite_get_bbox_top(v0) + 1
		var fa = max(1, ceil(abs(a4)))
		var tc = max(1, ceil(abs(a5)))
		var wv = max(1, cn - y4)
		var ww = max(1, cm - y5)
		var l8 = sprite_get_bbox_left(v0) - sprite_get_xoffset(v0)
		var ma = sprite_get_bbox_top(v0) - sprite_get_yoffset(v0)
		var xm = cn + (fa - 1) * wv
		var xk = cm + (tc - 1) * ww

		return
		{
			x: ae - l8 - xm * 0.5,
			y: af - ma - xk * 0.5
		}
	}

	var ck = (sprite_get_bbox_left(v0) + sprite_get_bbox_right(v0) + 1) * 0.5
	var cl = (sprite_get_bbox_top(v0) + sprite_get_bbox_bottom(v0) + 1) * 0.5
	var hg = a4

	if an == 4
	{
		hg = -abs(a4)
	}

	return
	{
		x: ae - (ck - sprite_get_xoffset(v0)) * hg,
		y: af - (cl - sprite_get_yoffset(v0)) * a5
	}
}

he = function(al, ab)
{
	var v0 = ks(al.kind)

	if al.kind == 0
	{
		var cn = sprite_get_bbox_right(v0) - sprite_get_bbox_left(v0) + 1
		var cm = sprite_get_bbox_bottom(v0) - sprite_get_bbox_top(v0) + 1
		var wv = max(1, cn - y4)
		var ww = max(1, cm - y5)
		var fa = max(1, ceil(abs(al.sx)))
		var tc = max(1, ceil(abs(al.sy)))

		for (var xx = 0; xx < fa; xx++)
		{
			for (var yy = 0; yy < tc; yy++)
			{
				draw_sprite_ext(v0, 0, al.x + xx * wv, al.y + yy * ww, 1, 1, 0, c_white, ab)
			}
		}

		return
	}

	if al.kind == 4
	{
		draw_sprite_ext(spr_cannonholder, 0, al.x, al.y, abs(al.sx), abs(al.sy), 0, c_white, ab)
	}

	var hf = al.sx

	if al.kind == 4
	{
		hf = -abs(al.sx)
	}

	draw_sprite_ext(v0, 0, al.x, al.y, hf, al.sy, al.rotation, c_white, ab)
}

ko = function(_x, _y)
{
	for (var i = array_length(kt) - 1; i >= 0; i--)
	{
		var dq = kp(kt[i])

		if (point_in_rectangle(_x, _y, dq.left, dq.top, dq.right, dq.bottom))
		{
			return i
		}
	}

	return -1
}

se = function(_x, _y, ay)
{
	if (um < 0 or um >= array_length(kt))
	{
		return -1
	}

	var dq = kp(kt[um])
	var fl = [dq.left, dq.right, dq.left, dq.right]
	var fm = [dq.top, dq.top, dq.bottom, dq.bottom]

	for (var fk = 0; fk < 4; fk++)
	{
		if (point_in_rectangle(
			_x,
			_y,
			fl[fk] - ay,
			fm[fk] - ay,
			fl[fk] + ay,
			fm[fk] + ay
			))
		{
			return fk
		}
	}

	return -1
}

uy = function(a6)
{
	wy = a6
	wz = 240
}

rc = function()
{
	array_push(x4, custom_level_clone_items(kt))

	if (array_length(x4) > jo)
	{
		array_delete(x4, 0, 1)
	}

	re = []
}

sa = function()
{
	um = -1
	hd = false
	sn = false
	g5 = false
	si = false
}

x3 = function()
{
	var fn = array_length(x4)

	if fn <= 0
	{
		return
	}

	array_push(re, custom_level_clone_items(kt))
	kt = x4[fn - 1]
	array_delete(x4, fn - 1, 1)
	sa()
}

rd = function()
{
	var fn = array_length(re)

	if fn <= 0
	{
		return
	}

	array_push(x4, custom_level_clone_items(kt))
	kt = re[fn - 1]
	array_delete(re, fn - 1, 1)
	sa()
}

ga = function(ak)
{
	if (ak >= 0 and ak < array_length(kt))
	{
		rc()
		array_delete(kt, ak, 1)
		sa()
	}
}

co = function()
{
	var o8 = 0

	for (var i = 0; i < array_length(kt); i++)
	{
		if kt[i].kind == 3
		{
			o8++
		}
	}

	if o8 != 1
	{
		uy("ADD PLAYER")
		return
	}

	tv = global.ty
	wn = []
	mu = 1
	um = -1
	hd = false
	sn = false

	global.ls = true
	global.lp = false
	global.lr = false

	camera_set_view_size(d8, cj, ci)

	for (var j = 0; j < array_length(kt); j++)
	{
		var kn = kt[j]
		var n7 = kr(kn.kind)
		var fo = instance_create_layer(kn.x, kn.y, "Instances", n7)

		fo.image_xscale = kn.sx

		if kn.kind == 4
		{
			fo.image_xscale = -abs(kn.sx)
		}

		fo.image_yscale = kn.sy
		fo.image_angle = kn.rotation

		array_push(wn, fo)
	}

	var camra = instance_create_layer(0, 0, "Instances", obj_camera_controller)
	array_push(wn, camra)
}

hv = function()
{
	global.ls = false
	global.lp = false
	global.lr = false
	global.wx = 1
	global.ty = tv

	for (var i = 0; i < array_length(wn); i++)
	{
		if (instance_exists(wn[i]))
		{
			instance_destroy(wn[i])
		}
	}

	wn = []
	mu = 0

	var yd = cj * hu
	var yc = ci * hu
	camera_set_view_size(d8, yd, yc)
	camera_set_view_pos(d8, hp, hq)

}

le = function()
{
	global.ln = false
	global.ls = false

	if (variable_global_exists("lq"))
	{
		room_goto(global.lq)
	}
	else
	{
		room_goto(room_tut1)
	}
}

tp = function(av)
{
	var e0 = string_trim(av)

	if (string_length(e0) <= 0)
	{
		renme = "Enter a name"
		return false
	}

	if (string_length(e0) > 80)
	{
		renme = "Use 80 characters or fewer"
		return false
	}

	if (hk >= 0 and hk < array_length(global.f2))
	{
		var r6 = global.f2[hk]
		var qc = r6.name
		r6.name = e0
		global.f2[hk] = r6

		if (!custom_levels_save())
		{
			r6.name = qc
			global.f2[hk] = r6
			renme = "Could not save name"
			return false
		}
	}

	ft = e0
	lv = true
	r4 = e0
	keyboard_string = e0
	return true
}

tn = function()
{
	var tt = custom_level_clone_items(kt)

	if (hk >= 0 and hk < array_length(global.f2))
	{
		var hy = global.f2[hk]
		hy.items = tt
		global.f2[hk] = hy
		ft = hy.name
	}
	else
	{
		if !lv
		{
			ft = custom_level_next_name()
		}

		var ng =
		{
			name: ft,
			items: tt,
			local_id: custom_level_make_id("level"),
			publish_token: custom_level_make_id("edit")
		}
		array_push(global.f2, ng)
		hk = array_length(global.f2) - 1
	}

	if (custom_levels_save())
	{
		uy("SAVED")
		p0 = true
		rf = true
		r4 = ft
		renme = ""
		keyboard_string = r4
		return true
	}
	else
	{
		uy("SAVE FAILED")
		return false
	}
}

if (variable_global_exists("lo"))
{
	var l3 = global.lo

	if (l3 >= 0 and l3 < array_length(global.f2))
	{
		hk = l3
		ft = global.f2[l3].name
		lv = true
		kt = custom_level_clone_items(global.f2[l3].items)
		wy = ""
		wz = 0
	}
}

global.lo = -1
