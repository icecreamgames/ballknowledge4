global.ln = false
global.ls = false
global.lp = false
global.lr = false
global.wx = 1

if rf
{
	keyboard_string = ""
}
