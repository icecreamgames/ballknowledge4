if mu != 0
{
	exit
}

draw_clear(make_color_rgb(25, 27, 30))

var yd = camera_get_view_width(d8)
var yc = camera_get_view_height(d8)
var ye = camera_get_view_x(d8)
var yf = camera_get_view_y(d8)
var i7 = floor(ye / i6) * i6
var i8 = floor(yf / i6) * i6

for (var gx = i7; gx <= ye + yd; gx += i6)
{
	var i9 = round(gx / i6)
	var ja = (abs(i9) mod 4) == 0

	if ja
	{
		draw_set_alpha(0.32)
		draw_set_color(make_color_rgb(125, 128, 134))
	}
	else
	{
		draw_set_alpha(0.14)
		draw_set_color(make_color_rgb(88, 91, 97))
	}

	draw_line(gx, yf, gx, yf + yc)
}

for (var gy = i8; gy <= yf + yc; gy += i6)
{
	var jb = round(gy / i6)
	var jc = (abs(jb) mod 4) == 0

	if jc
	{
		draw_set_alpha(0.32)
		draw_set_color(make_color_rgb(125, 128, 134))
	}
	else
	{
		draw_set_alpha(0.14)
		draw_set_color(make_color_rgb(88, 91, 97))
	}

	draw_line(ye, gy, ye + yd, gy)
}

draw_set_alpha(1)

for (var i = 0; i < array_length(kt); i++)
{
	var kn = kt[i]
	he(kn, 1)

	if i == um
	{
		var dq = kp(kn)
		draw_set_color(make_color_rgb(220, 222, 226))
		draw_set_alpha(0.95)
		draw_rectangle(dq.left - 4, dq.top - 4, dq.right + 4, dq.bottom + 4, true)

		var ji = 7 * yd / display_get_gui_width()
		var jh = 2 * yd / display_get_gui_width()
		var jk = [dq.left, dq.right, dq.left, dq.right]
		var jl = [dq.top, dq.top, dq.bottom, dq.bottom]

		for (var jg = 0; jg < 4; jg++)
		{
			draw_set_color(make_color_rgb(28, 30, 34))
			draw_rectangle(
				jk[jg] - ji - jh,
				jl[jg] - ji - jh,
				jk[jg] + ji + jh,
				jl[jg] + ji + jh,
				false
				)
			draw_set_color(make_color_rgb(210, 212, 216))
			draw_rectangle(
				jk[jg] - ji,
				jl[jg] - ji,
				jk[jg] + ji,
				jl[jg] + ji,
				false
				)
		}

		draw_set_alpha(1)
	}
}

var jf = display_get_gui_width()
var je = display_get_gui_height()
var mv = device_mouse_x_to_gui(0)
var mw = device_mouse_y_to_gui(0)

if mw > 112 and !hd and !sn and !op
{
	var m0 = ye + mv * yd / jf
	var m1 = yf + mw * yc / je
	var sx = 1
	var sy = 1

	if uv == 5
	{
		sx = 2
		sy = 0.5
	}

	var od = oe(uv, vj(m0), vj(m1), sx, sy)

	var i3 =
	{
		kind: uv,
		x: od.x,
		y: od.y,
		sx: sx,
		sy: sy,
		rotation: 0
	}
	he(i3, 0.52)
}

draw_set_alpha(1)
draw_set_color(c_white)
