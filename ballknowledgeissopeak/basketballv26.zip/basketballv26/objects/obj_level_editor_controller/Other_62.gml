if (!ds_map_exists(async_load, "id"))
{
	exit
}

var fi = async_load[? "id"]

if fi != publsh
{
	exit
}

var nb = -1
var j4 = 0
var ra = ""

if ds_map_exists(async_load, "status")
{
	nb = async_load[? "status"]
}

if ds_map_exists(async_load, "http_status")
{
	j4 = async_load[? "http_status"]
}

if ds_map_exists(async_load, "result")
{
	ra = async_load[? "result"]
}

publsh = -1

if nb != 0 or j4 < 200 or j4 >= 300
{
	var qg = "Publish failed"

	if nb != 0 and j4 <= 0
	{
		qg = "Could not reach the publishing server"
	}


	try
	{
		var hw = json_parse(ra)

		if (is_struct(hw)
			and variable_struct_exists(hw, "error")
			and string_length(hw.error) > 0)
		{
			qg = hw.error
		}
	} catch (z4)
	{
		show_debug_message("Could not parse publish error: " + string(z4))
	}

	renme = qg
	qs = ""
	keyboard_string = r4
	exit
}

try
{
	var so = json_parse(ra)

	if (!is_struct(so)
		or !variable_struct_exists(so, "level")
		or !is_struct(so.level)
		or !variable_struct_exists(so.level, "id"))
	{
		renme = "The server returned an invalid response"
		qs = ""
		keyboard_string = r4
		exit
	}

	var qo = false

	for (var i = 0; i < array_length(global.f2); i++)
	{
		var ll = global.f2[i]

		if ll.local_id == qs
		{
			ll.published_id = so.level.id
			global.f2[i] = ll
			qo = custom_levels_save()
			break
		}
	}

	if qo
	{
		renme = "Published successfully"
		uy("PUBLISHED")
	}
	else
	{
		renme = "Published, but the local update could not be saved"
	}
} catch (z4)
{
	show_debug_message("Could not parse publish response: " + string(z4))
	renme = "The server returned an invalid response"
}

qs = ""
keyboard_string = r4
