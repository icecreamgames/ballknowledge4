var jf = display_get_gui_width()
var je = display_get_gui_height()
var mv = device_mouse_x_to_gui(0)
var mw = device_mouse_y_to_gui(0)

if wz > 0
{
	wz--
}

if mu == 1
{
	if global.lr
	{
		global.lp = false

		if (mouse_check_button_pressed(mb_left))
		{
			var fe = jf * 0.5 - 245
			var ff = jf * 0.5 + 245
			var fd = je * 0.5 + 42
			var fc = fd + 58

			if (point_in_rectangle(
				mv,
				mw,
				fe + 24,
				fd,
				jf * 0.5 - 8,
				fc
				))
			{
				hv()
				exit
			}

			if (point_in_rectangle(
				mv,
				mw,
				jf * 0.5 + 8,
				fd,
				ff - 24,
				fc
				))
			{
				if (tn())
				{
					hv()
				}

				exit
			}
		}

		exit
	}

	var ca = jf - 166
	var cc = 18
	var cb = jf - 18
	var b9 = 70

	if (global.lp
		or (mouse_check_button_pressed(mb_left)
		and point_in_rectangle(mv, mw, ca, cc, cb, b9)))
	{
		hv()
	}

	exit
}

if ia
{
	var h7 = jf * 0.5 - 330
	var h8 = jf * 0.5 + 330
	var h1 = je * 0.5 + 36
	var hz = h1 + 48
	var h3 = h7 + 32
	var h4 = h8 - 32
	var h0 = 8
	var h2 = (h4 - h3 - h0 * 2) / 3
	var h5 = h3 + h2
	var ie = h5 + h0
	var ig = ie + h2
	var ib = ig + h0
	var ef = keyboard_check_pressed(vk_escape)
	or (mouse_check_button_pressed(mb_left)
		and point_in_rectangle(
		mv,
		mw,
		h3,
		h1,
		h5,
		hz
		))
	var ih = mouse_check_button_pressed(mb_left)
	and point_in_rectangle(
		mv,
		mw,
		ie,
		h1,
		ig,
		hz
		)
	var tm = keyboard_check_pressed(vk_enter)
	or (mouse_check_button_pressed(mb_left)
		and point_in_rectangle(
		mv,
		mw,
		ib,
		h1,
		h4,
		hz
		))

	if ef
	{
		ia = false
		ic = ""
		exit
	}

	if ih
	{
		le()
		exit
	}

	if tm
	{
		if (tn())
		{
			le()
		}
		else
		{
			ic = "Save failed"
		}

		exit
	}

	exit
}

if rf
{
	if publsh >= 0
	{
		exit
	}

	r4 = keyboard_string

	var rv = jf * 0.5 - 350
	var rw = jf * 0.5 + 350
	var ri = je * 0.5 + 72
	var rg = ri + 48
	var rk = rv + 32
	var rl = rw - 32
	var rh = 8
	var rj = (rl - rk - rh) / 2

	if p0
	{
		rj = (rl - rk - rh * 2) / 3
	}

	var rm = rk
	var rn = rm + rj
	var r2 = rn + rh
	var r3 = r2 + rj
	var r0 = r3 + rh
	var r1 = rl
	var eh = keyboard_check_pressed(vk_escape)
	or (mouse_check_button_pressed(mb_left)
		and point_in_rectangle(
		mv,
		mw,
		rm,
		ri,
		rn,
		rg
		))
	var tr = keyboard_check_pressed(vk_enter)
	or (mouse_check_button_pressed(mb_left)
		and point_in_rectangle(
		mv,
		mw,
		r2,
		ri,
		r3,
		rg
		))
	var qk = p0
	and mouse_check_button_pressed(mb_left)
	and point_in_rectangle(
		mv,
		mw,
		r0,
		ri,
		r1,
		rg
		)

	if eh
	{
		rf = false
		p0 = false
		r4 = ""
		renme = ""
		keyboard_string = ""
		exit
	}

	if tr or qk
	{
		if (tp(r4))
		{
			if qk
			{
				if (!custom_level_has_player(kt))
				{
					renme = "Add exactly one player before publishing"
				}
				else if (hk < 0 or hk >= array_length(global.f2))
				{
					renme = "Save the level before publishing"
				}
				else
				{
					var lz = global.f2[hk]
					qs = lz.local_id
					renme = "Publishing " + lz.name + "..."
					publsh = published_level_publish(lz)

					if publsh < 0
					{
						qs = ""
						renme = "Could not start the upload"
					}
				}
			}
			else
			{
				rf = false
				p0 = false
				r4 = ""
				renme = ""
				keyboard_string = ""
				uy("RENAMED")
			}
		}

		exit
	}

	exit
}

var yd = cj * hu
var yc = ci * hu
var d9 = 14 * hu

if (keyboard_check(ord("A")) or keyboard_check(vk_left))
{
	hp -= d9
}

if (keyboard_check(ord("D")) or keyboard_check(vk_right))
{
	hp += d9
}

if (keyboard_check(ord("W")) or keyboard_check(vk_up))
{
	hq -= d9
}

if (keyboard_check(ord("S")) or keyboard_check(vk_down))
{
	hq += d9
}

if (mouse_check_button_pressed(mb_middle))
{
	op = true
	k0 = mv
	k1 = mw
}

if (op and mouse_check_button(mb_middle))
{
	hp -= (mv - k0) * yd / jf
	hq -= (mw - k1) * yc / je
	k0 = mv
	k1 = mw
}

if (mouse_check_button_released(mb_middle))
{
	op = false
}

if (mouse_wheel_up())
{
	hu = max(0.6, hu - 0.1)
}

if (mouse_wheel_down())
{
	hu = min(2.25, hu + 0.1)
}

yd = cj * hu
yc = ci * hu

hp = clamp(hp, 0, max(0, room_width - yd))
hq = clamp(hq, 0, max(0, room_height - yc))

camera_set_view_size(d8, yd, yc)
camera_set_view_pos(d8, hp, hq)

var m0 = hp + mv * yd / jf
var m1 = hq + mw * yc / je
var og = mw <= 112

if (keyboard_check(vk_control) and keyboard_check_pressed(ord("Z")))
{
	if (keyboard_check(vk_shift))
	{
		rd()
	}
	else
	{
		x3()
	}
}
else if (keyboard_check(vk_control) and keyboard_check_pressed(ord("Y")))
{
	rd()
}

if (mouse_check_button_pressed(mb_left) and og)
{
	if (point_in_rectangle(mv, mw, 950, 77, 1024, 104))
	{
		x3()
	}

	if (point_in_rectangle(mv, mw, 1032, 77, 1110, 104))
	{
		rd()
	}

	if (point_in_rectangle(mv, mw, 556, 77, 650, 104))
	{
		p0 = false
		rf = true
		r4 = ft
		renme = ""
		keyboard_string = r4
		exit
	}

	if (point_in_rectangle(mv, mw, 12, 18, 78, 70))
	{
		ia = true
		ic = ""
		exit
	}

	for (var xf = 0; xf < array_length(xc); xf++)
	{
		var xd = 86 + xf * 94

		if (point_in_rectangle(mv, mw, xd, 18, xd + 86, 70))
		{
			uv = xc[xf]
		}
	}

	if (point_in_rectangle(mv, mw, 556, 18, 630, 70))
	{
		ga(um)
	}

	if (point_in_rectangle(mv, mw, 638, 18, 712, 70))
	{
		if (array_length(kt) > 0)
		{
			rc()
			kt = []
			sa()
		}
	}

	if (point_in_rectangle(mv, mw, 720, 18, 764, 70))
	{
		hu = min(2.25, hu + 0.1)
	}

	if (point_in_rectangle(mv, mw, 772, 18, 816, 70))
	{
		hu = max(0.6, hu - 0.1)
	}

	if (point_in_rectangle(mv, mw, 824, 18, 910, 70))
	{
		tn()
	}

	if (point_in_rectangle(mv, mw, jf - 166, 18, jf - 18, 70))
	{
		co()
	}
}

if !og and !op
{
	var mz = 2 * yd / jf

	if (mouse_check_button_pressed(mb_left))
	{
		var jj = 10 * yd / jf
		var fk = se(m0, m1, jj)

		if fk >= 0
		{
			var sd = kp(kt[um])
			sf = 1
			sg = 1
			sb = sd.left
			sc = sd.top

			if fk == 0 or fk == 2
			{
				sf = -1
				sb = sd.right
			}

			if fk == 0 or fk == 1
			{
				sg = -1
				sc = sd.bottom
			}

			sl = m0
			sm = m1
			si = false
			sn = true
			hd = false
		}
		else
		{
			var jp = ko(m0, m1)

			if jp >= 0
			{
				um = jp
				sn = false
				hd = true
				g5 = false
				hb = m0
				hc = m1

				var g2 = kp(kt[jp])
				g8 = (g2.left + g2.right) * 0.5 - m0
				g9 = (g2.top + g2.bottom) * 0.5 - m1
			}
			else
			{
				var sx = 1
				var sy = 1

				if uv == 5
				{
					sx = 2
					sy = 0.5
				}

				var ey = vj(m0)
				var ez = vj(m1)
				var od = oe(uv, ey, ez, sx, sy)

				if uv == 3
				{
					for (var p = 0; p < array_length(kt); p++)
					{
						if kt[p].kind == 3
						{
							if kt[p].x != od.x or kt[p].y != od.y
							{
								rc()
								kt[p].x = od.x
								kt[p].y = od.y
							}

							um = p
							sn = false
							hd = false
							exit
						}
					}
				}

				var ne =
				{
					kind: uv,
					x: od.x,
					y: od.y,
					sx: sx,
					sy: sy,
					rotation: 0
				}

				rc()
				array_push(kt, ne)
				um = array_length(kt) - 1
				sn = false
				hd = false
			}
		}
	}

	if (sn
		and um >= 0
		and um < array_length(kt)
		and mouse_check_button(mb_left)
		and point_distance(sl, sm, m0, m1) > mz)
	{
		var sj = kt[um]
		var sk = ks(sj.kind)
		var l8 = sprite_get_bbox_left(sk) - sprite_get_xoffset(sk)
		var l9 = sprite_get_bbox_right(sk) + 1 - sprite_get_xoffset(sk)
		var ma = sprite_get_bbox_top(sk) - sprite_get_yoffset(sk)
		var l7 = sprite_get_bbox_bottom(sk) + 1 - sprite_get_yoffset(sk)
		var wh = vj(m0)
		var wi = vj(m1)
		var mn = i6
		var nf
		var nj
		var nm
		var nc

		if sf < 0
		{
			nf = min(wh, sb - mn)
			nj = sb
		}
		else
		{
			nf = sb
			nj = max(wh, sb + mn)
		}

		if sg < 0
		{
			nm = min(wi, sc - mn)
			nc = sc
		}
		else
		{
			nm = sc
			nc = max(wi, sc + mn)
		}

		var nk
		var nl
		var nn
		var no

		if sj.kind == 0
		{
			var yv = max(1, l9 - l8)
			var ys = max(1, l7 - ma)
			var zb = max(1, yv - y4)
			var zc = max(1, ys - y5)
			var r9 = nj - nf
			var r8 = nc - nm

			nk = max(1, round((r9 - yv) / zb) + 1)
			nl = max(1, round((r8 - ys) / zc) + 1)

			var zd = yv + (nk - 1) * zb
			var y3 = ys + (nl - 1) * zc
			nf = sb
			nm = sc

			if sf < 0
			{
				nf = sb - zd
			}

			if sg < 0
			{
				nm = sc - y3
			}

			nn = nf - l8
			no = nm - ma
		}
		else
		{
			nk = (nj - nf) / max(1, l9 - l8)
			nl = (nc - nm) / max(1, l7 - ma)
			var nd = nk
			nn = nf - l8 * nd

			if sj.kind == 4
			{
				nd = -nk
				nn = nf - l9 * nd
			}

			no = nm - ma * nl
		}

		if (!si
			and (abs(sj.x - nn) > 0.001
			or abs(sj.y - no) > 0.001
			or abs(sj.sx - nk) > 0.001
			or abs(sj.sy - nl) > 0.001))
		{
			rc()
			si = true
		}

		kt[um].x = nn
		kt[um].y = no
		kt[um].sx = nk
		kt[um].sy = nl
	}

	if (hd
		and um >= 0
		and um < array_length(kt)
		and mouse_check_button(mb_left)
		and point_distance(hb, hc, m0, m1) > mz)
	{
		var g6 = kt[um]
		var g3 = vj(m0 + g8)
		var g4 = vj(m1 + g9)
		var ha = oe(g6.kind, g3, g4, g6.sx, g6.sy)

		if (!g5
			and (abs(g6.x - ha.x) > 0.001
			or abs(g6.y - ha.y) > 0.001))
		{
			rc()
			g5 = true
		}

		kt[um].x = ha.x
		kt[um].y = ha.y
	}

	if (mouse_check_button_released(mb_left))
	{
		hd = false
		sn = false
		g5 = false
		si = false
	}

	if (mouse_check_button_pressed(mb_right))
	{
		ga(ko(m0, m1))
	}
}

if (keyboard_check_pressed(vk_delete) or keyboard_check_pressed(vk_backspace))
{
	ga(um)
}
