if (!ds_map_exists(async_load, "id"))
{
	exit
}

var fi = async_load[? "id"]
var kl = fi == plyr_requst
var kk = fi == pj

if (fi != publsh
	and fi != gd
	and !kl
	and !kk)
{
	exit
}

var nb = -1
var j4 = 0
var ra = ""

if ds_map_exists(async_load, "status")
{
	nb = async_load[? "status"]
}

if ds_map_exists(async_load, "http_status")
{
	j4 = async_load[? "http_status"]
}

if ds_map_exists(async_load, "result")
{
	ra = async_load[? "result"]
}

if kl or kk
{
	if kl
	{
		plyr_requst = -1
	}

	if kk
	{
		pj = -1
	}

	if nb != 0 or j4 < 200 or j4 >= 300
	{
		var m8 = "Could not load your player name"

		if kk
		{
			m8 = "Could not change the player name"
		}


		try
		{
			var hw = json_parse(ra)

			if (is_struct(hw)
				and variable_struct_exists(hw, "error")
				and string_length(hw.error) > 0)
			{
				m8 = hw.error
			}
		} catch (z4)
		{
			show_debug_message("Could not parse player-name error: " + string(z4))
		}

		if kk
		{
			ph = m8
		}
		else
		{
			ql = m8
			qm = room_speed * 5
		}

		exit
	}

	try
	{
		var qf = json_parse(ra)

		if (!is_struct(qf)
			or !variable_struct_exists(qf, "player")
			or !is_struct(qf.player)
			or !variable_struct_exists(qf.player, "name")
			or string_length(qf.player.name) <= 0)
		{
			if kk
			{
				ph = "The server returned an invalid player name"
			}
			else
			{
				ql = "The server returned an invalid player name"
				qm = room_speed * 5
			}

			exit
		}

		pa = qf.player.name
		published_player_name_save(pa)

		if kk
		{
			pg = false
			pk = ""
			ph = ""
			keyboard_string = ""
			ql = "Player name changed to " + pa
			qm = room_speed * 4
		}
	} catch (z4)
	{
		show_debug_message("Could not parse player profile: " + string(z4))

		if kk
		{
			ph = "The server returned invalid player data"
		}
		else
		{
			ql = "The server returned invalid player data"
			qm = room_speed * 5
		}
	}

	exit
}

if fi == gd
{
	gd = -1

	if nb != 0 or j4 < 200 or j4 >= 300
	{
		ql = "Could not unpublish - level kept"
		qm = room_speed * 5
		gf = ""
		fj = -1
		exit
	}

	var f9 = -1

	for (var ge = 0; ge < array_length(global.f2); ge++)
	{
		if global.f2[ge].local_id == gf
		{
			f9 = ge
			break
		}
	}

	if f9 >= 0
	{
		array_delete(global.f2, f9, 1)

		if (custom_levels_save())
		{
			ql = "Level unpublished and deleted"
		}
		else
		{
			ql = "Unpublished, but local save failed"
		}

		t0 = clamp(t0, 0, max(0, array_length(global.f2) - yh))
	}
	else
	{
		ql = "Level unpublished"
	}

	qm = room_speed * 5
	gf = ""
	fj = -1
	exit
}

publsh = -1

if nb != 0 or j4 < 200 or j4 >= 300
{
	var qg = "Publish failed"

	if nb != 0 and j4 <= 0
	{
		qg = "Could not reach the publishing server"
	}


	try
	{
		var qh = json_parse(ra)

		if (is_struct(qh)
			and variable_struct_exists(qh, "error")
			and string_length(qh.error) > 0)
		{
			qg = qh.error
		}
	} catch (z4)
	{
		show_debug_message("Could not parse publish error: " + string(z4))
	}

	ql = qg
	qm = room_speed * 7
	qs = ""
	exit
}

try
{
	var so = json_parse(ra)

	if (!is_struct(so)
		or !variable_struct_exists(so, "level")
		or !is_struct(so.level)
		or !variable_struct_exists(so.level, "id"))
	{
		ql = "The server returned an invalid response"
		qm = room_speed * 5
		qs = ""
		exit
	}

	for (var i = 0; i < array_length(global.f2); i++)
	{
		var ll = global.f2[i]

		if ll.local_id == qs
		{
			ll.published_id = so.level.id
			global.f2[i] = ll
			custom_levels_save()
			break
		}
	}

	ql = "Published successfully"
	qm = room_speed * 4
} catch (z4)
{
	show_debug_message("Could not parse publish response: " + string(z4))
	ql = "The server returned an invalid response"
	qm = room_speed * 5
}

qs = ""
