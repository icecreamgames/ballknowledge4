var jf = display_get_gui_width()
var je = display_get_gui_height()
var mv = device_mouse_x_to_gui(0)
var mw = device_mouse_y_to_gui(0)
var lm = array_length(global.f2)
var mf = max(0, lm - yh)

if qm > 0
{
	qm--

	if (qm <= 0
		and publsh < 0
		and gd < 0
		and plyr_requst < 0
		and pj < 0)
	{
		ql = ""
	}
}

if gd >= 0
{
	j0 = -1
	jy = -1
	scrlling = false
	exit
}

if mouse_wheel_up()
{
	t0--
}

if mouse_wheel_down()
{
	t0++
}
t0 = clamp(t0, 0, mf)

if mf > 0 and ro < 0 and !pg
{
	var t6 = jf - 58
	var t8 = jf - 42
	var uc = 142
	var t1 = min(je - 106, 142 + yh * 82 - 16)
	var t4 = t1 - uc
	var ua = max(52, t4 * yh / lm)
	var ud = max(1, t4 - ua)
	var ub = uc + ud * t0 / mf

	if (mouse_check_button_pressed(mb_left)
		and point_in_rectangle(
		mv,
		mw,
		t6 - 7,
		uc,
		t8 + 7,
		t1
		))
	{
		scrlling = true

		if mw >= ub and mw <= ub + ua
		{
			tz = mw - ub
		}
		else
		{
			tz = ua * 0.5
		}
	}

	if (scrlling and mouse_check_button(mb_left))
	{
		var t3 = clamp((mw - tz - uc) / ud, 0, 1)
		t0 = round(t3 * mf)
	}
}
else
{
	scrlling = false
}

if (mouse_check_button_released(mb_left))
{
	scrlling = false
}

j0 = -1
jy = -1

if pg
{
	if pj >= 0
	{
		exit
	}

	pk = keyboard_string

	var pe = jf * 0.5 - 320
	var pf = jf * 0.5 + 320
	var o5 = je * 0.5 + 58
	var o3 = o5 + 48
	var o6 = pe + 32
	var o7 = jf * 0.5 - 8
	var pl = jf * 0.5 + 8
	var pm = pf - 32
	var eg = keyboard_check_pressed(vk_escape)
	or (mouse_check_button_pressed(mb_left)
		and point_in_rectangle(
		mv,
		mw,
		o6,
		o5,
		o7,
		o3
		))
	var tq = keyboard_check_pressed(vk_enter)
	or (mouse_check_button_pressed(mb_left)
		and point_in_rectangle(
		mv,
		mw,
		pl,
		o5,
		pm,
		o3
		))

	if eg
	{
		pg = false
		pk = ""
		ph = ""
		keyboard_string = ""
		exit
	}

	if tq
	{
		var ni = string_trim(pk)

		if (string_length(ni) <= 0)
		{
			ph = "Enter a player name"
		}
		else if (string_length(ni) > 40)
		{
			ph = "Use 40 characters or fewer"
		}
		else if ni == pa
		{
			pg = false
			pk = ""
			ph = ""
			keyboard_string = ""
		}
		else
		{
			ph = "Checking name..."
			pj = published_player_name_change(ni)

			if pj < 0
			{
				ph = "Could not contact the name server"
			}
		}

		exit
	}

	exit
}

if ro >= 0
{
	r4 = keyboard_string

	var rv = jf * 0.5 - 320
	var rw = jf * 0.5 + 320
	var ri = je * 0.5 + 58
	var rg = ri + 48
	var rm = rv + 32
	var rn = jf * 0.5 - 8
	var r2 = jf * 0.5 + 8
	var r3 = rw - 32
	var eh = keyboard_check_pressed(vk_escape)
	or (mouse_check_button_pressed(mb_left)
		and point_in_rectangle(
		mv,
		mw,
		rm,
		ri,
		rn,
		rg
		))
	var tr = keyboard_check_pressed(vk_enter)
	or (mouse_check_button_pressed(mb_left)
		and point_in_rectangle(
		mv,
		mw,
		r2,
		ri,
		r3,
		rg
		))

	if eh
	{
		ro = -1
		r4 = ""
		renme = ""
		keyboard_string = ""
		exit
	}

	if tr
	{
		var nh = string_trim(r4)

		if (string_length(nh) <= 0)
		{
			renme = "Enter a name"
		}
		else if (ro < array_length(global.f2))
		{
			var r6 = global.f2[ro]
			r6.name = nh
			global.f2[ro] = r6
			custom_levels_save()
			ro = -1
			r4 = ""
			renme = ""
			keyboard_string = ""
		}

		exit
	}

	exit
}

if (mouse_check_button_pressed(mb_left))
{
	if (point_in_rectangle(mv, mw, 24, 24, 140, 76))
	{
		room_goto(room_main_menu)
		exit
	}

	var pc = jf - 98
	var pb = pc - 180
	var o2 = je - 82
	var oz = je - 22

	if (point_in_rectangle(
		mv,
		mw,
		pb,
		o2 + 9,
		pc,
		oz - 9
		))
	{
		if plyr_requst < 0 and pj < 0
		{
			pg = true
			pk = pa

			if pa == "Getting a name..."
			{
				pk = ""
			}

			ph = ""
			keyboard_string = pk
			fj = -1
		}

		exit
	}

	if (point_in_rectangle(mv, mw, jf - 220, 24, jf - 24, 76))
	{
		global.lo = -1
		global.lq = room_custom_levels
		room_goto(room_level_editor)
		exit
	}
}

var tb = 142
var ta = 82

for (var vh = 0; vh < yh; vh++)
{
	var ka = t0 + vh

	if ka >= lm
	{
		break
	}

	var xj = tb + vh * ta
	var dm = xj + 66

	if (point_in_rectangle(mv, mw, 78, xj, jf - 78, dm))
	{
		j0 = ka
	}

	var bg = 88
	var bf = 8
	var ox = jf - 78 - bg * 5 - bf * 4
	var hj = ox + bg + bf
	var rt = hj + bg + bf
	var qj = rt + bg + bf
	var gc = qj + bg + bf

	if (point_in_rectangle(mv, mw, ox, xj + 10, ox + bg, dm - 10))
	{
		jy = 0
	}
	else if (point_in_rectangle(mv, mw, hj, xj + 10, hj + bg, dm - 10))
	{
		jy = 1
	}
	else if (point_in_rectangle(mv, mw, rt, xj + 10, rt + bg, dm - 10))
	{
		jy = 2
	}
	else if (point_in_rectangle(mv, mw, qj, xj + 10, qj + bg, dm - 10))
	{
		jy = 3
	}
	else if (point_in_rectangle(mv, mw, gc, xj + 10, gc + bg, dm - 10))
	{
		jy = 4
	}

	if (mouse_check_button_pressed(mb_left) and j0 == ka)
	{
		if jy == 0
		{
			global.f0 = ka
			room_goto(room_custom_level_play)
			exit
		}

		if jy == 1
		{
			global.lo = ka
			global.lq = room_custom_levels
			room_goto(room_level_editor)
			exit
		}

		if jy == 2
		{
			ro = ka
			r4 = global.f2[ka].name
			renme = ""
			keyboard_string = r4
			fj = -1
			exit
		}

		if jy == 3
		{
			if publsh < 0
			{
				var lz = global.f2[ka]
				qs = lz.local_id
				ql = "Publishing " + lz.name + "..."
				qm = 0
				publsh = published_level_publish(lz)

				if publsh < 0
				{
					qs = ""
					ql = "Could not start the upload"
					qm = room_speed * 4
				}
			}

			exit
		}

		if jy == 4
		{
			if fj == ka
			{
				var ly = global.f2[ka]

				if publsh >= 0
				{
					ql = "Wait for publishing to finish"
					qm = room_speed * 4
				}
				else if (variable_struct_exists(ly, "published_id"))
				{
					gf = ly.local_id
					ql = "Unpublishing " + ly.name + "..."
					qm = 0
					gd = published_level_unpublish(ly)

					if gd < 0
					{
						gf = ""
						ql = "Could not start unpublishing"
						qm = room_speed * 5
					}
				}
				else
				{
					array_delete(global.f2, ka, 1)
					custom_levels_save()
					ql = "Level deleted"
					qm = room_speed * 3
					fj = -1
					t0 = clamp(t0, 0, max(0, array_length(global.f2) - yh))
				}
			}
			else
			{
				fj = ka
			}

			exit
		}

		fj = -1
	}
}
