custom_levels_load()
t0 = 0
yh = 6
scrlling = false
tz = 0
fj = -1
j0 = -1
jy = -1
ro = -1
r4 = ""
renme = ""
pa = published_player_name()
pg = false
pk = ""
ph = ""
plyr_requst = published_player_profile_fetch()
pj = -1
publsh = -1
qs = ""
gd = -1
gf = ""
ql = ""
qm = 0

if plyr_requst < 0
{
	ql = "Could not load your player name"
	qm = room_speed * 5
}
