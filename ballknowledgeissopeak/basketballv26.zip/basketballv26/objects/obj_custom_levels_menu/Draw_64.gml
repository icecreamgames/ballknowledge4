var jf = display_get_gui_width()
var je = display_get_gui_height()
var mv = device_mouse_x_to_gui(0)
var mw = device_mouse_y_to_gui(0)
var bgc = make_color_rgb(25, 27, 30)
var ok = make_color_rgb(38, 40, 44)
var ol = make_color_rgb(48, 50, 55)
var dh = make_color_rgb(27, 29, 32)
var wo = make_color_rgb(238, 238, 238)
var m5 = make_color_rgb(156, 159, 166)

draw_clear(bgc)

draw_set_font(Font1)
draw_set_halign(fa_center)
draw_set_valign(fa_middle)

ui_draw_menu_button(24, 24, 140, 76, "Back", mv, mw)
ui_draw_menu_button(jf - 220, 24, jf - 24, 76, "New level", mv, mw)

draw_set_color(wo)
draw_text_transformed(jf * 0.5, 48, "Levels", 2.2, 2.2, 0)

if (string_length(ql) > 0)
{
	draw_set_color(m5)
	draw_text(jf * 0.5, 108, ql)
}

var lm = array_length(global.f2)
var tb = 142
var ta = 82

if lm == 0
{
	draw_set_color(m5)
	draw_text_transformed(jf * 0.5, je * 0.5, "No levels", 1.5, 1.5, 0)
}

for (var vh = 0; vh < yh; vh++)
{
	var ka = t0 + vh

	if ka >= lm
	{
		break
	}

	var ll = global.f2[ka]
	var xj = tb + vh * ta
	var dm = xj + 66
	var s9 = ok

	if j0 == ka
	{
		s9 = ol
	}

	var bg = 88
	var bf = 8
	var ox = jf - 78 - bg * 5 - bf * 4
	var hj = ox + bg + bf
	var rt = hj + bg + bf
	var qj = rt + bg + bf
	var gc = qj + bg + bf

	draw_set_color(s9)
	draw_rectangle(78, xj, jf - 78, dm, false)
	draw_set_color(dh)
	draw_rectangle(78, xj, jf - 78, dm, true)

	draw_set_halign(fa_left)
	draw_set_color(wo)
	var i0 = ll.name
	var u1 = i0
	var m9 = ox - 126

	while (string_width(u1) > m9 and string_length(u1) > 4)
	{
		u1 = string_delete(u1, string_length(u1), 1)
	}

	if u1 != i0
	{
		u1 += "..."
	}

	draw_text(106, (xj + dm) * 0.5, u1)

	draw_set_halign(fa_center)
	ui_draw_menu_button(ox, xj + 10, ox + bg, dm - 10, "Play", mv, mw)
	ui_draw_menu_button(hj, xj + 10, hj + bg, dm - 10, "Edit", mv, mw)
	ui_draw_menu_button(rt, xj + 10, rt + bg, dm - 10, "Rename", mv, mw)
	var qi = "Publish"

	if variable_struct_exists(ll, "published_id")
	{
		qi = "Update"
	}

	ui_draw_menu_button(qj, xj + 10, qj + bg, dm - 10, qi, mv, mw)
	var gb = "Delete"

	if fj == ka
	{
		gb = "Confirm"
	}

	if gf == ll.local_id
	{
		gb = "Wait..."
	}

	ui_draw_menu_button(
		gc,
		xj + 10,
		gc + bg,
		dm - 10,
		gb,
		mv,
		mw
		)
}

if lm > yh
{
	var t6 = jf - 58
	var t8 = jf - 42
	var uc = tb
	var t1 = min(je - 106, tb + yh * ta - 16)
	var t4 = t1 - uc
	var t7 = lm - yh
	var ua = max(52, t4 * yh / lm)
	var ub = uc
	+ (t4 - ua) * t0 / t7
	var t9 = ub + ua
	var t5 = point_in_rectangle(
		mv,
		mw,
		t6 - 5,
		ub,
		t8 + 5,
		t9
		)

	draw_set_color(dh)
	draw_rectangle(t6, uc, t8, t1, false)
	draw_set_color(make_color_rgb(53, 56, 62))
	draw_rectangle(t6 + 3, uc + 3, t8 - 3, t1 - 3, false)
	var t2 = make_color_rgb(110, 116, 126)

	if t5 or scrlling
	{
		t2 = make_color_rgb(67, 139, 171)
	}

	draw_set_color(t2)
	draw_rectangle(t6, ub, t8, t9, false)
	draw_set_color(wo)
	draw_triangle(t6, uc - 8, t8, uc - 8, (t6 + t8) * 0.5, uc - 17, false)
	draw_triangle(t6, t1 + 8, t8, t1 + 8, (t6 + t8) * 0.5, t1 + 17, false)
}

var o0 = 78
var o1 = jf - 78
var o2 = je - 82
var oz = je - 22
var pc = o1 - 20
var pb = pc - 180

draw_set_color(ok)
draw_rectangle(o0, o2, o1, oz, false)
draw_set_color(dh)
draw_rectangle(o0, o2, o1, oz, true)

var i1 = "Your profile: " + pa
var u2 = i1
var pd = pb - o0 - 48

draw_set_halign(fa_left)

while (string_width(u2) > pd and string_length(u2) > 4)
{
	u2 = string_delete(u2, string_length(u2), 1)
}

if u2 != i1
{
	u2 += "..."
}

draw_set_color(wo)
draw_text(106, (o2 + oz) * 0.5, u2)

draw_set_halign(fa_center)
var o4 = "Change name"

if plyr_requst >= 0
{
	o4 = "Loading..."
}

ui_draw_menu_button(
	pb,
	o2 + 9,
	pc,
	oz - 9,
	o4,
	mv,
	mw
	)

if ro >= 0 or pg
{
	var om = jf * 0.5 - 320
	var on = jf * 0.5 + 320
	var oo = je * 0.5 - 130
	var oj = je * 0.5 + 126
	var kd = om + 32
	var ke = on - 32
	var ki = je * 0.5 - 28
	var kb = je * 0.5 + 24
	var d6 = je * 0.5 + 58

	draw_set_alpha(0.58)
	draw_set_color(c_black)
	draw_rectangle(0, 0, jf, je, false)

	draw_set_alpha(1)
	draw_set_color(ok)
	draw_rectangle(om, oo, on, oj, false)
	draw_set_color(dh)
	draw_rectangle(om, oo, on, oj, true)

	draw_set_halign(fa_center)
	draw_set_valign(fa_middle)
	draw_set_color(wo)
	var gk = "Rename level"

	if pg
	{
		gk = "Change player name"
	}

	draw_text_transformed(jf * 0.5, oo + 56, gk, 1.5, 1.5, 0)

	draw_set_color(bgc)
	draw_rectangle(kd, ki, ke, kb, false)
	draw_set_color(dh)
	draw_rectangle(kd, ki, ke, kb, true)

	var uz = r4

	if pg
	{
		uz = pk
	}

	while (string_width(uz + "|") > ke - kd - 24 and string_length(uz) > 0)
	{
		uz = string_delete(uz, 1, 1)
	}

	if ((current_time div 500) mod 2 == 0)
	{
		uz += "|"
	}

	draw_set_halign(fa_left)
	draw_set_color(wo)
	draw_text(kd + 12, (ki + kb) * 0.5, uz)

	var gj = renme

	if pg
	{
		gj = ph
	}

	if (string_length(gj) > 0)
	{
		draw_set_halign(fa_center)
		draw_set_color(m5)
		draw_text(jf * 0.5, je * 0.5 + 40, gj)
	}

	ui_draw_menu_button(om + 32, d6, jf * 0.5 - 8, d6 + 48, "Cancel", mv, mw)
	var to = "Save"

	if pj >= 0
	{
		to = "Checking..."
	}

	ui_draw_menu_button(jf * 0.5 + 8, d6, on - 32, d6 + 48, to, mv, mw)
}

draw_set_halign(fa_left)
draw_set_valign(fa_top)
draw_set_alpha(1)
draw_set_color(c_white)
