k5 += 1
sprite_index = spr_ball_transition
instance_destroy(other)

if (instance_exists(obj_tutorial3) and !obj_tutorial3.xy and !obj_tutorial3.xv)
{
	obj_tutorial3.xw = true
}
