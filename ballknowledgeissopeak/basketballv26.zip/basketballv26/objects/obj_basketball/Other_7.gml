if sprite_index == spr_ball_transition
{
	sprite_index = sprite_basketblue
}
