if (variable_global_exists("ls") and global.ls)
{
	global.lp = true
}
else
{
	room_restart()
}
