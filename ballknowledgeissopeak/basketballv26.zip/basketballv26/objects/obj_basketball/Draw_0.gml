if bk
{

	var dx = bn
	var dy = bo
	var g7 = point_distance(0, 0, dx, dy)

	if g7 > 10
	{

		var gl = point_direction(0, 0, dx, dy)

		var k2 = min(g7 * br, bq)

		var px = x
		var py = y
		var vx = lengthdir_x(k2, gl)

		var vy = lengthdir_y(k2, gl)

		var i5 = gravty
		var iz = ot
		var mc = ou
		var mg = -ov
		var js = false

		draw_set_color(c_white)
		draw_set_alpha(0.9)

		for (var i = 0; i < 90; i++)
		{
			vy += i5

			vx *= iz

			vx = clamp(vx, -mc, mc)

			var wc = max(1, ceil(max(abs(vx), abs(vy))))

			var mx = vx / wc
			var my = vy / wc

			repeat (wc)
			{
				if mx != 0
				{
					if (place_meeting(px + mx, py, obj_floor))
					{
						js = true
						break
					}

					px += mx
				}

				if my != 0
				{
					if (place_meeting(px, py + my, obj_floor))
					{
						js = true
						break
					}

					py += my
				}
			}

			if js
			{
				break
			}

			if i mod 3 == 0
			{
				draw_circle(px, py, 4, false)
			}

			if vy < mg
			{
				vy = mg
			}
		}

	}
}

draw_set_alpha(1)
draw_set_color(c_white)
if er > 0
{
	var dr = clamp(er, 0, 1)
	var ds = point_direction(0, 0, j1, yp)
	var dw = ch * lerp(1, 1.28, dr)
	var dz = ch * lerp(1, 0.66, dr)
	var dv = (sprite_get_bbox_right(sprite_index)
		- sprite_get_bbox_left(sprite_index) + 1) * dw * 0.5
	var du = (sprite_get_bbox_bottom(sprite_index)
		- sprite_get_bbox_top(sprite_index) + 1) * dz * 0.5
	var nt = dv * 0.58
	var nz = dv * 1.18
	var nw = du * 0.42
	var nu = x + lengthdir_x(nt, ds)
	var nv = y + lengthdir_y(nt, ds)
	var n0 = x + lengthdir_x(nz, ds)
	var n1 = y + lengthdir_y(nz, ds)

	draw_set_alpha(image_alpha * dr)
	draw_set_color(make_color_rgb(92, 42, 18))
	draw_triangle(
		nu + lengthdir_x(nw + 2, ds + 90),
		nv + lengthdir_y(nw + 2, ds + 90),
		nu + lengthdir_x(nw + 2, ds - 90),
		nv + lengthdir_y(nw + 2, ds - 90),
		n0 + lengthdir_x(3, ds),
		n1 + lengthdir_y(3, ds),
		false
		)

	draw_set_color(make_color_rgb(232, 111, 31))
	draw_triangle(
		nu + lengthdir_x(nw, ds + 90),
		nv + lengthdir_y(nw, ds + 90),
		nu + lengthdir_x(nw, ds - 90),
		nv + lengthdir_y(nw, ds - 90),
		n0,
		n1,
		false
		)

	draw_set_alpha(1)
	draw_set_color(c_white)
	draw_sprite_ext(
		sprite_index,
		image_index,
		x,
		y,
		dw,
		dz,
		ds,
		image_blend,
		image_alpha
		)
}
else
{
	draw_sprite_ext(sprite_index, image_index, x, y, yj, yk, vv, image_blend, image_alpha)
}

draw_set_alpha(1)
draw_set_color(c_white)

