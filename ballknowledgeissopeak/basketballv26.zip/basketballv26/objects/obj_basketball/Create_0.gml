j1 = 0
yp = 0

gravty = 1
ot = 0.984
ou = 50
ov = 40
ip = false
global.xn = part_system_create()

global.xo = part_type_create()
part_type_shape(global.xo, pt_shape_star)
part_type_color3(global.xo, c_red, c_blue, c_white)
part_type_life(global.xo, 40, 60)
part_type_direction(global.xo, 240, 300, 0, 0)
part_type_speed(global.xo, 1, 3, -0.02, 0)
part_type_gravity(global.xo, 0.1, 270)
eo = 0
k3 = 0
ek = 0
el = false
em = 0
eu = false
er = 0
ev = 80
ob = false
mask_index = Sprite6
vv = 0
image_angle = 0

ch = max(abs(image_xscale), abs(image_yscale), 1)
v7 = 0
v8 = 0
y9 = 0
za = 0
v9 = 1
wa = 1
yj = ch
yk = ch

yi = false

f8 = false
po = 0
depth = -100000
k4 = 0
vd = 80
u5 = 40
vb = false

alarm[1] = 30
bk = false
k5 = 0
bw = 0
bz = 0
we = 0
bm = 0

bn = 0
bo = 0

bs = 1.5
bt = false

bu = 0.10
br = 0.20
bq = 35

global.wx = 1

vg = false
bl = 90
b0 = 2
bp = 50000
zi = true
