if zi
{
	audio_play_sound(snd_whistle, 1, false)
	zi = false
}
if !yi
{
	ch = max(abs(image_xscale), abs(image_yscale), 1)
	image_xscale = ch
	image_yscale = ch
	yj = ch
	yk = ch
	yi = true
}

var fz = variable_global_exists("f1")
and global.f1
and variable_global_exists("fw")
and global.fw
var ht = variable_global_exists("ls")
and global.ls
and variable_global_exists("lr")
and global.lr

if fz or ht
{
	j1 = 0
	yp = 0
	bk = false
	vg = false
	global.wx = 1
	exit
}

if (instance_exists(obj_lava))
{
	var k6 = instance_find(obj_lava, 0)

	if k6.k9 == 1
	{
		exit
	}
}

if (instance_exists(obj_tutorial3))
{
	if obj_tutorial3.xy
	{
		exit
	}
}

if ek > 0
{
	ek--
}

if eo == 1
{
	j1 = 0
	yp = 0
	bk = false
	vg = false
	global.wx = 1
	exit
}

var i5 = gravty
var dp = 0.82
var yw = 0.75
var b1 = ot
var jd = 0.9
var mm = 2
var mh = ov
var nr = ou
var jv = nr
var x7 = mh

if el
{
	jv = max(jv, em)
	x7 = max(x7, em)

	if (abs(j1) <= nr and yp >= -mh)
	{
		el = false
		em = 0
		eu = false
		jv = nr
		x7 = mh
	}
}

var et = point_distance(0, 0, j1, yp)
var es = 0

if eu
{
	es = clamp((et - 35) / max(1, ev - 35), 0, 1)

	if et <= 38
	{
		eu = false
		es = 0
	}
}

er = lerp(er, es, 0.18)

if !eu and er < 0.01
{
	er = 0
}

var ve = 32
var u8 = 4
var u6 = 0.95
var u9 = max(ve, min(u5, mh))

if (!variable_instance_exists(id, "u7"))
{
	u7 = ve
}

if (!variable_instance_exists(id, "vc"))
{
	vc = 0
}

u7 = clamp(u7, ve, u9)

if (!variable_instance_exists(id, "k4"))
{
	k4 = 0
}

if k4 > 0
{
	k4--
}

image_angle = 0
mask_index = sprite_index

if bm > 0
{
	bm--
}

var oa = place_meeting(x, y + 1, obj_floor)

var kd = keyboard_check(vk_left)
or keyboard_check(ord("A"))
var ke = keyboard_check(vk_right)
or keyboard_check(ord("D"))
var kc = keyboard_check_pressed(vk_down)
or keyboard_check_pressed(ord("S"))
var kg = keyboard_check_pressed(vk_space)
var kh = keyboard_check_released(vk_space)

if (variable_global_exists("mp"))
kd = kd or global.mp

if (variable_global_exists("mq"))
ke = ke or global.mq

if (variable_global_exists("mo"))
kc = kc or global.mo

if (variable_global_exists("ms"))
kg = kg or global.ms

if (variable_global_exists("mt"))
kh = kh or global.mt

if (bk and !window_has_focus())
{
	bk = false
	bm = 12
}

if !bk and k5 > 0 and bm <= 0 and !oa and kg
{
	bk = true
	bl = 90
	vg = false
}

if bk
{
	if (keyboard_check_pressed(vk_escape))
	{
		bk = false
		bm = 12
	}
	else
	{
		if kd
		{
			bl += b0
		}

		if ke
		{
			bl -= b0
		}

		bl = ((bl mod 360) + 360) mod 360

		var yg = bp
		/ max(0.001, br)

		bn = lengthdir_x(yg, bl)

		bo = lengthdir_y(yg, bl)

		if kh
		{
			if k5 > 0
			{
				var k2 = min(bp, bq)

				j1 = lengthdir_x(k2, bl)

				yp = lengthdir_y(k2, bl)

				k5 -= 1

				k3 = 20
				vg = false

				k4 = 12
			}

			bk = false
			bm = 12
		}
	}
}

var dt = 1

if bk
{
	dt = bu
}

global.wx = dt

if k3 > 0
{
	k3--
}
else if !bk
{
	if ke
	{
		j1 += 1.2 * dt
	}

	if kd
	{
		j1 -= 1.2 * dt
	}
}

if (!bk and (kg or keyboard_check_pressed(ord("W"))))
{
	alarm[0] = 30
}

if !bk
{
	var va = kc

	if va
	{
		if oa
		{

			vg = false

			yp = -u7
		}
		else
		{

			vg = true
			yp = vd
		}
	}

	if vg and !oa
	{
		yp = max(yp, vd)
	}
}

yp += i5 * dt

j1 *= power(b1, dt)

j1 = clamp(j1, -jv, jv)

if oa
{
	j1 *= power(jd, dt)

	if (abs(j1) < 0.35)
	{
		j1 = 0
	}
}

if (place_meeting(x, y, obj_floor))
{
	var n8 = x
	var n9 = y
	var hx = false

	for (var r = 1; r <= 32 and !hx; r++)
	{
		for (var a = 0; a < 360; a += 45)
		{
			var nx = n8 + lengthdir_x(r, a)
			var ny = n9 + lengthdir_y(r, a)

			if (!place_meeting(nx, ny, obj_floor))
			{
				x = nx
				y = ny

				j1 = 0
				yp = 0

				hx = true
				break
			}
		}
	}

	if !hx
	{
		j1 = 0
		yp = 0
		exit
	}
}

var m3 = j1 * dt
var m4 = yp * dt
var wc = max(1, ceil(max(abs(m3), abs(m4))))

var mx = m3 / wc
var my = m4 / wc
var dn = false

repeat (wc)
{

	var lf = instance_place(x + mx, y + my, obj_lebron)

	if lf == noone
	{
		lf = instance_place(x + mx, y, obj_lebron)
	}

	if lf == noone
	{
		lf = instance_place(x, y + my, obj_lebron)
	}

	if lf != noone
	{
		var lx = (lf.bbox_left + lf.bbox_right) / 2

		var bx = (bbox_left + bbox_right) / 2

		var u4 = sign(bx - lx)

		if u4 == 0
		{
			u4 = sign(lf.j1)
		}

		if u4 == 0
		{
			u4 = choose(-1, 1)
		}

		j1 = u4 * (max(6, abs(j1)) + abs(lf.j1))

		yp = -max(8, abs(yp) * 0.9 + abs(lf.j1) * 0.5)

		k3 = 30

		break
	}

	if mx != 0
	{
		if (place_meeting(x + mx, y, obj_floor))
		{
			eu = false

			if (abs(j1) > 2)
			{
				za = min(abs(j1) * 0.012, 0.12)
			}

			j1 = -j1 * yw

			if (abs(j1) < 1)
			{
				j1 = 0
			}

			mx = 0
		}
		else
		{
			x += mx
		}
	}

	if my != 0
	{
		if (place_meeting(x, y + my, obj_floor))
		{
			eu = false

			if my > 0
			{

				if (abs(yp) > 2)
				{
					dn = true

					v8 = min(abs(yp) * 0.012, 0.12)
				}

				var z1 =
				abs(yp) * dp

				if vg
				{

					u7 = min(u7 + u8, u9)

					z1 = max(u7, abs(yp) * u6)
					z1 = min(z1, u5)

					vg = false
					vb = true
				}

				if alarm[0] > 0
				{
					z1 += 5
					alarm[0] = -1
				}

				if z1 < mm
				{
					yp = 0
				}
				else
				{
					yp = -z1
				}
			}
			else
			{

				yp = abs(yp) * yw

				if yp < 1
				{
					yp = 0
				}

				vg = false
			}

			my = 0
		}
		else
		{
			y += my
		}
	}
}

if dn
{
	audio_play_sound(bounce, 1, false)

	var ya = (bbox_left + bbox_right) * 0.5
	- sprite_get_width(spr_jumpvfx) * 0.5
	+ sprite_get_xoffset(spr_jumpvfx)
	var yb = bbox_bottom + 1
	- sprite_get_bbox_bottom(spr_jumpvfx)
	+ sprite_get_yoffset(spr_jumpvfx)

	instance_create_depth(ya, yb, depth + 1, obj_jump_vfx)
}

ob = place_meeting(x, y + 1, obj_floor)

if ob
{
	we = 1
}
else
{
	we = 0
}

if (ob and abs(yp) < 1 and !vg)
{
	vc++

	if vc >= 15
	{
		u7 = ve
	}
}
else
{
	vc = 0
}

if (!bk
	and ob
	and (
	kg
	or keyboard_check_pressed(vk_up)
	or keyboard_check_pressed(ord("W"))
	))
{
	yp = -12
}

if (ob and abs(j1) < 0.35)
{
	j1 = 0
}

var wd = 0.35
var f6 = 0.22

v8 += (-v7) * wd * dt - v8 * f6 * dt
v7 += v8 * dt

za += (-y9) * wd * dt - za * f6 * dt
y9 += za * dt

v9 = 1 + v7 - y9
wa = 1 - v7 + y9

var vw = max(
	sprite_get_bbox_right(sprite_index) - sprite_get_bbox_left(sprite_index) + 1,
	sprite_get_bbox_bottom(sprite_index) - sprite_get_bbox_top(sprite_index) + 1
	)
var vz = max(1, vw * ch * 0.5)
vv -= (j1 * dt / vz) * (180 / pi)

image_xscale = ch
image_yscale = ch

yj = ch * v9
yk = ch * wa

if vb
{
	x7 = max(x7, u5)
}

if yp < -x7
{
	yp = -x7
}

if vb and yp >= -mh
{
	vb = false
}

if k5 == 0
{
	sprite_index = spr_new_basketball
}

if k5 > 100
{
	sprite_index = Sprite10
}

if !oa and ip and yp <= 0
{
	if (abs(j1) > 0.5 or abs(yp) > 0.5)
	{
		part_particles_create(global.xn, x, y, global.xo, 4)
	}
}

if oa and ip
{
	ip = false
}
