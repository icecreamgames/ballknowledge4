instance_destroy(self)
audio_stop_all()
audio_play_sound(Sound3, 1, true)
obj_manager.x8 = true
obj_basketball.k5 = 100000000000000000000000000000
