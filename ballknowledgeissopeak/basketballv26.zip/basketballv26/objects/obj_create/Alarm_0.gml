instance_destroy(self)
