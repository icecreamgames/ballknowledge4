audio_stop_all()

if (!variable_global_exists("ty"))
{
	global.ty = 0
}

alarm[0] = 60
audio_play_sound(snd_badmusic,1,1)
window_set_fullscreen(true)
