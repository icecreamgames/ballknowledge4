var fz = variable_global_exists("f1")
and global.f1
and variable_global_exists("fw")
and global.fw
var ht = variable_global_exists("ls")
and global.ls
and variable_global_exists("lr")
and global.lr

if fz or ht
{
	exit
}

var jq = instance_place(x, y, obj_basketball)

if jq != noone and jq.eo == 0
{
	jq.visible = false

	if (variable_global_exists("ls") and global.ls)
	{
		global.lp = true
	}
	else
	{
		room_restart()
	}
}
