if (instance_exists(yx))
{
	instance_destroy(yx)
}
