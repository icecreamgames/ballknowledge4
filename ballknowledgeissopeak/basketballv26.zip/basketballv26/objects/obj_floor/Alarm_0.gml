yz = max(1, ceil(abs(image_xscale)))
y7 = max(1, ceil(abs(image_yscale)))

var yt = sprite_get_bbox_left(y8)
var yu = sprite_get_bbox_top(y8)
var yv = sprite_get_bbox_right(y8) - yt + 1
var ys = sprite_get_bbox_bottom(y8) - yu + 1
var wv = max(1, yv - y4)
var ww = max(1, ys - y5)
var e9 = yv + (yz - 1) * wv
var e8 = ys + (y7 - 1) * ww

yx = instance_create_layer(
	x + yt - sprite_get_xoffset(y8),
	y + yu - sprite_get_yoffset(y8),
	layer,
	obj_floorinv
	)
yx.image_xscale = e9 / sprite_get_width(Sprite2)
yx.image_yscale = e8 / sprite_get_height(Sprite2)

image_xscale = 1
image_yscale = 1
image_angle = 0
y6 = true
