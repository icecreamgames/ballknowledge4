y8 = sprite_index
y0 = floor(image_index)
yz = max(1, ceil(abs(image_xscale)))
y7 = max(1, ceil(abs(image_yscale)))
y4 = 35
y5 = 22
yx = noone
y6 = false

sprite_index = -1
mask_index = -1
alarm[0] = 1
