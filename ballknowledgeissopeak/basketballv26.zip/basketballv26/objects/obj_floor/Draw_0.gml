var sw = sprite_get_bbox_right(y8)
- sprite_get_bbox_left(y8) + 1
var sh = sprite_get_bbox_bottom(y8)
- sprite_get_bbox_top(y8) + 1
var fa = max(1, ceil(abs(image_xscale)))
var tc = max(1, ceil(abs(image_yscale)))

if y6
{
	fa = yz
	tc = y7
}

for (var xx = 0; xx < fa; xx++)
{
	for (var yy = 0; yy < tc; yy++)
	{
		draw_sprite(y8, y0, x + xx * (sw - y4), y + yy * (sh - y5))
	}
}
