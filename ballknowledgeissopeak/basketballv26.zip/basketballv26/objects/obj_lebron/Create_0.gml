yp=0
j1=0
ob=false
po = 0
f8 = false
