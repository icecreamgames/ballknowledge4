j1 = 0

if (keyboard_check(ord("D")))
{
	j1 = 4
}

if (keyboard_check(ord("A")))
{
	j1 = -4
}

if (keyboard_check(ord("W")))
{
	if (place_meeting(x, y + 20, obj_floor))
	{
		yp = -15
	}
}

yp += 0.5

var jt = j1
var j3 = ceil(abs(jt))

if j3 > 0
{
	var j2 = jt / j3

	for (var i = 0; i < j3; i++)
	{
		if (!place_meeting(x + j2, y, obj_floor))
		{
			x += j2
		}
		else
		{
			j1 = 0
			break
		}
	}
}

var yl = yp
var yr = ceil(abs(yl))

if yr > 0
{
	var yq = yl / yr

	for (var j = 0; j < yr; j++)
	{
		if (!place_meeting(x, y + yq, obj_floor))
		{
			y += yq
		}
		else
		{
			if yp > 0
			{

				if alarm[0] > 0
				{
					yp -= 5
					alarm[0] = -1
				}
			}
			else
			{

				yp = 0
			}

			break
		}
	}
}

if yp < -20
{
	yp = -20
}

ob = place_meeting(x, y + 1, obj_floor)
