if !f8
{
	po += 1
}

f8 = true
alarm[0] = 60
