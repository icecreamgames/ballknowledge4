var jf = display_get_gui_width()
var je = display_get_gui_height()
var mv = device_mouse_x_to_gui(0)
var mw = device_mouse_y_to_gui(0)
var d7 = 430
var d2 = 68
var d4 = (jf - d7) * 0.5
var iq = je * 0.46

jz = -1

for (var i = 0; i < 4; i++)
{
	var xj = iq + i * 82

	if (point_in_rectangle(mv, mw, d4, xj, d4 + d7, xj + d2))
	{
		jz = i
	}
}

if (mouse_check_button_pressed(mb_left) and jz >= 0)
{
	switch (jz)
	{
		case 0:
			global.ty = 0
			room_goto(room_tut1_1)
			break

		case 1:
			global.lo = -1
			global.lq = room_main_menu
			room_goto(room_level_editor)
			break

		case 2:
			room_goto(room_custom_levels)
			break

		case 3:
			room_goto(room_published_levels)
			break
	}
}
