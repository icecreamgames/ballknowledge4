var jf = display_get_gui_width()
var je = display_get_gui_height()
var mv = device_mouse_x_to_gui(0)
var mw = device_mouse_y_to_gui(0)
var oq = make_color_rgb(244, 237, 219)
var d1 = make_color_rgb(70, 73, 79)
var d0 = make_color_rgb(27, 29, 32)
var d5 = make_color_rgb(238, 238, 238)

draw_set_font(Font1)
draw_set_halign(fa_center)
draw_set_valign(fa_middle)

draw_set_color(oq)

var kz = [
	"Play",
	"Build a level",
	"My levels  (" + string(array_length(global.f2)) + ")",
	"Published levels"
	]
var d7 = 430
var d2 = 68
var d4 = (jf - d7) * 0.5
var iq = je * 0.46

for (var i = 0; i < 4; i++)
{
	var xj = iq + i * 82
	ui_draw_button(
		d4,
		xj,
		d4 + d7,
		xj + d2,
		kz[i],
		d1,
		d0,
		d5,
		mv,
		mw,
		2.2
		)
}

draw_set_halign(fa_left)
draw_set_valign(fa_top)
draw_set_alpha(1)
draw_set_color(c_white)
