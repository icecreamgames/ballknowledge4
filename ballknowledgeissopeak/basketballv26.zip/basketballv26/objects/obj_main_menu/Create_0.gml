gpu_set_texfilter(false)
window_set_fullscreen(true)
custom_levels_load()

if (!variable_global_exists("ty"))
{
	global.ty = 0
}

if (!audio_is_playing(snd_badmusic))
{
	audio_play_sound(snd_badmusic, 1, true)
}

jz = -1

var dk = 32
var ju = room_width / sprite_get_width(Sprite2)
var x9 = (room_height - dk * 2) / sprite_get_height(Sprite2)
var dl = instance_create_layer(0, 0, "Instances", obj_floorinv)
dl.image_xscale = ju
dl.image_yscale = dk / sprite_get_height(Sprite2)

var dg = instance_create_layer(0, room_height - dk, "Instances", obj_floorinv)
dg.image_xscale = ju
dg.image_yscale = dk / sprite_get_height(Sprite2)

var di = instance_create_layer(0, dk, "Instances", obj_floorinv)
di.image_xscale = dk / sprite_get_width(Sprite2)
di.image_yscale = x9

var dj = instance_create_layer(room_width - dk, dk, "Instances", obj_floorinv)
dj.image_xscale = dk / sprite_get_width(Sprite2)
dj.image_yscale = x9

instance_create_layer(room_width * 0.22, room_height * 0.28, "Instances", obj_menu_basketball)
