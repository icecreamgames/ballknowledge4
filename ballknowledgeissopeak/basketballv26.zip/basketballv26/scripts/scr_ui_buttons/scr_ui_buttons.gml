function ui_draw_outlined_text(_x, _y, a6, a0 = 1, a7 = c_white, aw = c_black)
{
	var of = max(1, a0 * 0.75)

	draw_set_color(aw)
	draw_text_transformed(_x - of, _y, a6, a0, a0, 0)
	draw_text_transformed(_x + of, _y, a6, a0, a0, 0)
	draw_text_transformed(_x, _y - of, a6, a0, a0, 0)
	draw_text_transformed(_x, _y + of, a6, a0, a0, 0)
	draw_text_transformed(_x - of, _y - of, a6, a0, a0, 0)
	draw_text_transformed(_x + of, _y - of, a6, a0, a0, 0)
	draw_text_transformed(_x - of, _y + of, a6, a0, a0, 0)
	draw_text_transformed(_x + of, _y + of, a6, a0, a0, 0)

	draw_set_color(a7)
	draw_text_transformed(_x, _y, a6, a0, a0, 0)
}

function ui_draw_button(
	ap,
	a9,
	az,
	ad,
	ao,
	ah,
	ac,
	a7,
	z0,
	at,
	a8 = 1
	)
{
	var jx = point_in_rectangle(z0, at, ap, a9, az, ad)
	var ik = ah

	if jx
	{
		ik = merge_color(ah, c_black, 0.18)
	}

	draw_set_color(ik)
	draw_roundrect_ext(ap, a9, az, ad, 8, 8, false)
	draw_set_color(ac)
	draw_roundrect_ext(ap, a9, az, ad, 8, 8, true)

	if (string_length(ao) > 0)
	{
		draw_set_halign(fa_center)
		draw_set_valign(fa_middle)
		var jw = 1

		if jx
		{
			jw = 1.08
		}

		var kw = a8 * jw
		var kx = round((ap + az) * 0.5)
		var ky = round((a9 + ad) * 0.5 - 2.5 * kw)

		ui_draw_outlined_text(kx, ky, ao, kw, a7, c_black)
	}

	return jx
}

function ui_draw_key(a3, ae, af, a0, aj)
{
	var iv = max(1, sprite_get_number(a3))
	var hh = ae + (sprite_get_xoffset(a3) - sprite_get_width(a3) * 0.5) * a0
	var hi = af + (sprite_get_yoffset(a3) - sprite_get_height(a3) * 0.5) * a0

	draw_sprite_ext(a3, aj mod iv, round(hh), round(hi), a0, a0, 0, c_white, 1)
}

function ui_draw_menu_button(ap, a9, az, ad, ao, z0, at)
{
	return ui_draw_button(
		ap,
		a9,
		az,
		ad,
		ao,
		make_color_rgb(70, 73, 79),
		make_color_rgb(27, 29, 32),
		make_color_rgb(238, 238, 238),
		z0,
		at
		)
}

function ui_draw_toggle_button(ap, a9, az, ad, ao, aa, z0, at)
{
	var ik = make_color_rgb(70, 73, 79)

	if aa
	{
		ik = make_color_rgb(102, 106, 114)
	}

	return ui_draw_button(
		ap,
		a9,
		az,
		ad,
		ao,
		ik,
		make_color_rgb(27, 29, 32),
		make_color_rgb(238, 238, 238),
		z0,
		at
		)
}

function ui_draw_selected_button(ap, a9, az, ad, ao, a1, z0, at)
{
	var ik = make_color_rgb(70, 73, 79)

	if a1
	{
		ik = make_color_rgb(42, 92, 116)
	}

	return ui_draw_button(
		ap,
		a9,
		az,
		ad,
		ao,
		ik,
		make_color_rgb(27, 29, 32),
		make_color_rgb(238, 238, 238),
		z0,
		at
		)
}

function ui_draw_vote_button(ap, a9, az, ad, ba, ag, z0, at)
{
	var jx = ui_draw_menu_button(ap, a9, az, ad, "", z0, at)
	var ey = ap + 24
	var ez = (a9 + ad) * 0.5
	var wu = -1
	var j5 = make_color_rgb(238, 126, 126)

	if ba
	{
		wu = 1
		j5 = make_color_rgb(118, 218, 144)
	}

	draw_set_color(j5)

	var oi = ez - 3 * wu
	var oh = ez + 12 * wu
	draw_rectangle(ey - 7, min(oi, oh), ey + 9, max(oi, oh), false)

	var im = ez - 3 * wu
	var il = ez + 2 * wu
	draw_rectangle(ey + 8, min(im, il), ey + 15, max(im, il), false)
	im = ez + 2 * wu
	il = ez + 7 * wu
	draw_rectangle(ey + 8, min(im, il), ey + 14, max(im, il), false)
	im = ez + 7 * wu
	il = ez + 12 * wu
	draw_rectangle(ey + 8, min(im, il), ey + 13, max(im, il), false)

	draw_triangle(ey - 7, ez - 2 * wu, ey - 3, ez - 7 * wu, ey + 3, ez - 2 * wu, false)
	draw_triangle(ey - 3, ez - 7 * wu, ey - 1, ez - 15 * wu, ey + 3, ez - 2 * wu, false)
	draw_triangle(ey - 1, ez - 15 * wu, ey + 4, ez - 16 * wu, ey + 3, ez - 2 * wu, false)
	draw_triangle(ey + 4, ez - 16 * wu, ey + 7, ez - 13 * wu, ey + 3, ez - 2 * wu, false)
	draw_triangle(ey + 7, ez - 13 * wu, ey + 6, ez - 8 * wu, ey + 3, ez - 2 * wu, false)

	var fs = ez + 3 * wu
	var fr = ez + 13 * wu
	draw_rectangle(ey - 15, min(fs, fr), ey - 8, max(fs, fr), false)
	draw_set_color(make_color_rgb(27, 29, 32))
	draw_rectangle(ey - 9, min(fs, fr), ey - 8, max(fs, fr), false)

	var wq = 1

	if jx
	{
		wq = 1.08
	}

	ui_draw_outlined_text(ap + 56, ez, string(ag), wq, make_color_rgb(238, 238, 238), c_black)
}
