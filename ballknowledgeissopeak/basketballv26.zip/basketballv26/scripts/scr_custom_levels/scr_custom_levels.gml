function custom_levels_load(ai = false)
{
	if (!ai and variable_global_exists("f3") and global.f3)
	{
		return global.f2
	}

	global.f2 = []
	global.f3 = true

	var ij = "basketball_custom_levels.json"

	if (!file_exists(ij))
	{
		return global.f2
	}

	var ii = file_text_open_read(ij)

	if ii < 0
	{
		return global.f2
	}

	var ku = ""

	while (!file_text_eof(ii))
	{
		ku += file_text_read_string(ii)
		file_text_readln(ii)
	}

	file_text_close(ii)

	if (string_length(ku) <= 0)
	{
		return global.f2
	}

	try
	{
		var l6 = json_parse(ku)

		if (is_array(l6))
		{
			global.f2 = l6

			var ts = false

			for (var i = 0; i < array_length(global.f2); i++)
			{
				var l5 = global.f2[i]

				if (!variable_struct_exists(l5, "local_id"))
				{
					l5.local_id = custom_level_make_id("level")
					ts = true
				}

				if (!variable_struct_exists(l5, "publish_token"))
				{
					l5.publish_token = custom_level_make_id("edit")
					ts = true
				}

				global.f2[i] = l5
			}

			if ts
			{
				custom_levels_save()
			}
		}
	} catch (z4)
	{
		show_debug_message("Could not read custom levels: " + string(z4))
		global.f2 = []
	}

	return global.f2
}

function custom_level_make_id(ax)
{
	var n5 = floor(date_current_datetime() * 86400000)
	return ax + "_" + string(n5) + "_" + string(irandom(2147483646))
}

function custom_levels_save()
{
	if (!variable_global_exists("f2"))
	{
		global.f2 = []
	}

	var ij = "basketball_custom_levels.json"
	var ii = file_text_open_write(ij)

	if ii < 0
	{
		return false
	}

	file_text_write_string(ii, json_stringify(global.f2))
	file_text_close(ii)
	return true
}

function custom_level_clone_items(am)
{
	var e7 = []

	for (var i = 0; i < array_length(am); i++)
	{
		var kn = am[i]

		array_push(e7,
			{
				kind: kn.kind,
				x: kn.x,
				y: kn.y,
				sx: kn.sx,
				sy: kn.sy,
				rotation: kn.rotation
			})
	}

	return e7
}

function custom_level_has_player(am)
{
	var o8 = 0

	for (var i = 0; i < array_length(am); i++)
	{
		if am[i].kind == 3
		{
			o8++
		}
	}

	return o8 == 1
}

function custom_level_next_name()
{
	custom_levels_load()

	var n6 = array_length(global.f2) + 1
	var m7 = false
	var ei = ""

	while !m7
	{
		ei = "My Level " + string(n6)
		m7 = true

		for (var i = 0; i < array_length(global.f2); i++)
		{
			if global.f2[i].name == ei
			{
				m7 = false
				n6++
				break
			}
		}
	}

	return ei
}
