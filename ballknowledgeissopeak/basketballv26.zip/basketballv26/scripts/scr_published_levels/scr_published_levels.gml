function published_levels_api_url()
{
	return "https://ballknowlegde.netlify.app/api/levels"
}

function published_player_id()
{
	if (variable_global_exists("qr") and string_length(global.qr) > 0)
	{
		return global.qr
	}

	var ij = "basketball_player_id.txt"
	var o9 = ""

	if (file_exists(ij))
	{
		var rb = file_text_open_read(ij)

		if rb >= 0
		{
			o9 = string_trim(file_text_read_string(rb))
			file_text_close(rb)
		}
	}

	if (string_length(o9) <= 0)
	{
		o9 = custom_level_make_id("player")
		var zj = file_text_open_write(ij)

		if zj >= 0
		{
			file_text_write_string(zj, o9)
			file_text_close(zj)
		}
	}

	global.qr = o9
	return o9
}

function published_player_name()
{
	if (variable_global_exists("qq")
		and string_length(global.qq) > 0)
	{
		return global.qq
	}

	var ij = "basketball_player_profile.json"

	if (file_exists(ij))
	{
		var rb = file_text_open_read(ij)

		if rb >= 0
		{
			var qe = ""

			while (!file_text_eof(rb))
			{
				qe += file_text_read_string(rb)
				file_text_readln(rb)
			}

			file_text_close(rb)

			try
			{
				var tu = json_parse(qe)

				if (is_struct(tu)
					and variable_struct_exists(tu, "name")
					and string_length(tu.name) > 0)
				{
					global.qq = tu.name
					return global.qq
				}
			} catch (z4)
			{
				show_debug_message("Could not read player profile: " + string(z4))
			}
		}
	}

	return "Getting a name..."
}

function published_player_name_save(au)
{
	var e0 = string_trim(au)

	if (string_length(e0) <= 0)
	{
		return false
	}

	global.qq = e0

	var ij = "basketball_player_profile.json"
	var zj = file_text_open_write(ij)

	if zj < 0
	{
		return false
	}

	file_text_write_string(zj, json_stringify({ name: e0 }))
	file_text_close(zj)
	return true
}

function published_json_headers()
{
	var jn = ds_map_create()
	ds_map_add(jn, "Content-Type", "text/plain;charset=UTF-8")
	ds_map_add(jn, "Accept", "application/json")
	return jn
}

function published_levels_fetch(a2)
{
	var jn = published_json_headers()
	var r7 = http_request(published_levels_api_url() + "?sort=" + a2, "GET", jn, "")
	ds_map_destroy(jn)
	return r7
}

function published_levels_refresh()
{
	if l1 >= 0
	{
		return
	}

	n2 = "Loading published levels..."
	n3 = 0
	l1 = published_levels_fetch(vm[vp])

	if l1 < 0
	{
		n2 = "Could not start the download"
		n3 = room_speed * 5
	}
}

function published_player_profile_fetch()
{
	var jn = published_json_headers()
	var os =
	{
		player_id: published_player_id()
	}
	var r7 = http_request(
		"https://ballknowlegde.netlify.app/api/player",
		"POST",
		jn,
		json_stringify(os)
		)
	ds_map_destroy(jn)
	return r7
}

function published_player_name_change(au)
{
	var jn = published_json_headers()
	var os =
	{
		player_id: published_player_id(),
		display_name: string_trim(au)
	}
	var r7 = http_request(
		"https://ballknowlegde.netlify.app/api/player",
		"POST",
		jn,
		json_stringify(os)
		)
	ds_map_destroy(jn)
	return r7
}

function published_level_publish(aq)
{
	var jn = published_json_headers()
	var os =
	{
		source_id: aq.local_id,
		edit_token: aq.publish_token,
		author_id: published_player_id(),
		author_name: published_player_name(),
		name: aq.name,
		items: custom_level_clone_items(aq.items)
	}
	var r7 = http_request(published_levels_api_url(), "POST", jn, json_stringify(os))
	ds_map_destroy(jn)
	return r7
}

function published_level_unpublish(aq)
{
	var jn = published_json_headers()
	var os =
	{
		edit_token: aq.publish_token
	}
	var r7 = http_request(
		published_levels_api_url()
		+ "/"
		+ string(aq.published_id)
		+ "/unpublish",
		"POST",
		jn,
		json_stringify(os)
		)
	ds_map_destroy(jn)
	return r7
}

function published_level_vote(ar, bb)
{
	var jn = published_json_headers()
	var os =
	{
		voter_id: published_player_id(),
		value: bb
	}
	var r7 = http_request(
		published_levels_api_url() + "/" + ar + "/vote",
		"POST",
		jn,
		json_stringify(os)
		)
	ds_map_destroy(jn)
	return r7
}
